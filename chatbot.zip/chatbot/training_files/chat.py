import os
import joblib
import faiss
from langchain.chat_models import ChatOpenAI
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQAWithSourcesChain, LLMChain
from langchain.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from langchain.memory import ConversationBufferMemory
from langchain import OpenAI
from langchain.sql_database import SQLDatabase
from langchain.agents import create_sql_agent
from langchain.agents import AgentType, initialize_agent, AgentExecutor
# from langchain.agents.agent_types import AgentType
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from langchain.schema.messages import SystemMessage
from langchain.tools import BaseTool, StructuredTool, Tool, tool
from langchain.agents.agent_toolkits import SQLDatabaseToolkit
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from fastapi import FastAPI, WebSocket
import uvicorn
import boto3
from fastapi.responses import HTMLResponse

load_dotenv()

app = FastAPI()

def initialize_classifier_chain():
    prompt = ChatPromptTemplate.from_messages(
            [
            SystemMessage(
                content=(
                    "As an AI you are given an task of classifying user's text"
                    "Classify as follows give Yes if user text is part of normal human dialog/conversation and if it is a question related to you, else give No if it requires any additional information about any person, place etc. other than chatting."
                    "Examples: Give Yes to, what is your name?, Who are you?, how you feeling?, etc."
                    "Examples: Give No to, what is weather today?, Fuck you!, etc."
                    "Answer in Yes or No only."
                    )
            ),
            HumanMessagePromptTemplate.from_template("{text}"),
            ]
        )
    classifier=ChatOpenAI(model = "gpt-3.5-turbo")
    classifier_chain = LLMChain(llm=classifier, prompt=prompt)#, memory=memory_classifier)
    return classifier_chain

def initialize_conversational_chain():

    chat_template = ChatPromptTemplate.from_messages(
        [
            SystemMessage(
                content=(
                    "You are an AI assitant and your name is Humza."
                    "You are a helpful assistant that respond to user's text and does a friendly conversation with user."
                    "Only be limited to normal chatting"
                    # "Be creative and answer general question and respond that you dont know when ask about about something that require additional information."
                )
            ),
            HumanMessagePromptTemplate.from_template("{text}"),
        ]
    )
    llm=ChatOpenAI(temperature=1, model_name='gpt-3.5-turbo')
    # memory_conversational = ConversationBufferMemory(memory_key="chat_history",output_key="answer", input_key="text")
    conversational_chain = LLMChain(llm=llm,prompt=chat_template,memory=ConversationBufferMemory())#memory=memory_conversational)
    print("conversational unit initialized")
    return conversational_chain

def initialize_retrieval_chain():
    llm=ChatOpenAI(temperature=0, model_name='gpt-3.5-turbo')

    with open("PW_faiss_store_openai.pkl", "rb") as f:
        vectorStore_openAI = joblib.load(f)

    # QA_memory = ConversationBufferMemory(memory_key="chat_history",output_key="answer", input_key="question")

    retrieval_chain = RetrievalQAWithSourcesChain.from_llm(llm=llm, retriever=vectorStore_openAI.as_retriever())#, memory=QA_memory)
    retrieval_chain.return_source_documents=False
    print("web retrieval unit initialized")
    return retrieval_chain

def initialize_db_retrieval_chain():
    session = boto3.Session(aws_access_key_id='AKIAUCVMOYIN346USQP3', aws_secret_access_key='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')
    rds = session.client('rds',region_name='ap-south-1')
    endpoint = rds.describe_db_instances(DBInstanceIdentifier='karachihills')['DBInstances'][0]['Endpoint']['Address']
    db1 = SQLDatabase.from_uri("postgresql://postgres:Panasonic1@"+endpoint+":5432/property_wallet",
                               include_tables=["user","listing","hot_listing","inventory","lead","lead_inventory","lead_permission","pw_assign_package","pw_sub_package"])

    toolkit1 = SQLDatabaseToolkit(db=db1, llm=ChatOpenAI(temperature=0))
    agent = create_sql_agent(
        llm=ChatOpenAI(temperature=0, model_name='gpt-3.5-turbo-16k'),
        toolkit=toolkit1,
        verbose=True,
        agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        max_iterations=50,
        early_stopping_method="generate",
    )
    # db_agent = AgentExecutor(agent=agent,handle_parsing_errors=True)
    db_agent = agent
    print("db retrieval unit initialized")
    return db_agent


conversational_chain = initialize_conversational_chain()
retrieval_chain = initialize_retrieval_chain()
db_agent = initialize_db_retrieval_chain()


class Query(BaseModel):
    Question : str

@app.post('/chat')
async def chatbot(query : Query):

    # try:
        question=query.Question

        if question=="":
            print("Refresh")
            return { 'data':[{
                    'question' : "Refresh",
                    'answer' : "How can I help You!",
                    'sources' : None
            }]}

        classifier_chain = initialize_classifier_chain()
        output = classifier_chain.run(text=question)
        print(output)

        if output=="Yes" or output=="Yes.":
            conversational_chain = initialize_conversational_chain()
            output = conversational_chain.run(text=question)
            return { 'data':[{
                    'question' : question,
                    'answer' : output,
                    'sources' : None
                }]}

        else:
            retrieval_chain = initialize_retrieval_chain()
            # ans = retrieval_chain(return_only_outputs=True).run(question)
            ans = retrieval_chain({"question": question}, return_only_outputs=True)

            if ans['answer']== "I don't know.\n":
                return { 'data':[{
                    'question' : question,
                    'answer' : "Sorry I don't have any particular information about this, give some more insight or contact directly to property wallet help team.",
                    'sources' : None
                }]}
            else:
                return { 'data':[{
                    'question' : question,
                    'answer' : ans['answer'],
                    'sources' : ans['sources']
                }]}

    # except:
    #     return "An error occured"


class User(BaseModel):
    Id : int

@app.post("/chat2")
async def chatbot(query : Query):
    # try:
        userid=1
        question=query.Question

        if question=="":
            print("Refresh")
            # return
            return { 'data':[{
                    'question' : "Refresh",
                    'answer' : "How can I help You!",
                    'sources' : None
            }]}

        # classifier_chain = initialize_classifier_chain()
        multi_tools = [
            Tool.from_function(
                func = conversational_chain.run,
                name = "chit chat",
                description = (
                        "You are an AI assitant and your name is Humza."
                        "As an AI assistant you shouldres pond to user's text and does a friendly conversation with user."
                        "You should only limit yourself to normal chatting"
                        ),
                return_direct = True
            ),
            Tool.from_function(
                func = retrieval_chain,
                name = "Information retriever",
                description = "useful for answering frequently asked questions about property wallet"
            ),
            Tool.from_function(
                func = db_agent.run,
                name = "User data information retriever",
                description = (
                        # "Give below information correspond to user id "+ str(userid) +" from property wallet database"
                        f"Useful for retrieving information about leads, associated inventories and its permissions generated by user whose id is {userid}."
                        f"Useful for retrieving information about views of inventories, listings and hot listings viewed by user whose id is {userid}."
                        f"Useful for retrieving information about property wallet package, sub package bought by user whose id is {userid}."
                        f"Useful for retrieving information about inventories, listing and hot listings created and added by user whose id is {userid}."
                )
                #  """useful for retrieving data related to user generated leads, lead inventories, lead_permission,
                # view_inventory, view_listing_and_hot_listing, pw_assign_package, pw_package, pw_sub_package, inventory, listing, hot_listing, user.
                # \n\nGive above information related to user id """+ str(userid) +""" from SQL database""",
                # return_direct = True
                # args_schema = User
            )
        ]
        agent_llm = ChatOpenAI(model="gpt-3.5-turbo")
        # agent_executer = AgentExecutor(tools=multi_tools,llm=agent_llm,agent=AgentType.CHAT_CONVERSATIONAL_REACT_DESCRIPTION,memory=ConversationBufferMemory())
        # agent = initialize_agent(tools=multi_tools,llm=agent_llm,agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,handle_parsing_errors=True)
        agent_chain = initialize_agent(tools=multi_tools, llm=agent_llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, handle_parsing_errors=True)#, verbose=True, memory=ConversationBufferMemory(memory_key="chat_history", return_messages=True))#,max_iterations=2,early_stopping_method="generate",handle_parsing_errors=True)
        output = agent_chain.run(question)
        # output = agent_executer.invoke(question)['output']
        return { 'data':[{
                'question' : question,
                'answer' : output,
                'sources' : None
            }]}

    # except:
    #     return { 'data':[{
    #             'question' : question,
    #             'answer' : "I don't know",
    #             'sources' : None
    #         }]}


@app.websocket("/chat_ws")
async def websocket_endpoint(websocket: WebSocket):
    # conversational_chain = initialize_conversational_chain()
    # retrieval_chain = initialize_retrieval_chain()
    # db_agent = initialize_db_retrieval_chain()

    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        print(data)
        try:
            userid=1
            question=data

            if question=="":
                print("Refresh")
                output = "How can I help You!"

            else:
                multi_tools = [
                    Tool.from_function(
                        func = conversational_chain.run,
                        name = "chit chat",
                        description = (
                                "You are an AI assitant and your name is Humza."
                                "As an AI assistant you shouldres pond to user's text and does a friendly conversation with user."
                                "You should only limit yourself to normal chatting"
                                ),
                        return_direct = True
                    ),
                    Tool.from_function(
                        func = retrieval_chain,
                        name = "Information retriever",
                        description = "useful for retrieving information about property wallet"
                    ),
                ]
                agent_llm = ChatOpenAI(model="gpt-3.5-turbo")
                agent_chain = initialize_agent(tools=multi_tools, llm=agent_llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, handle_parsing_errors=True)#, verbose=True, memory=ConversationBufferMemory(memory_key="chat_history", return_messages=True))#,max_iterations=2,early_stopping_method="generate",handle_parsing_errors=True)
                output = agent_chain.run(question)

            print(output)
            await websocket.send_text(f"Message text was: {output}")
            # await websocket.send_json({
            #                             'data':[{
            #                             'question' : question,
            #                             'answer' : output,
            #                             }]
            #                         })

        except:
            await websocket.send_text("Message text was: **I don't know** ")
            # await websocket.send_json({
            #                             'data':[{
            #                             'question' : question,
            #                             'answer' : "I don't know",
            #                             }]
            #                         })

html = """
<!DOCTYPE html>
<html>
    <head>
        <title>Chat</title>
    </head>
    <body>
        <h1>WebSocket Chat</h1>
        <form action="" onsubmit="sendMessage(event)">
            <input type="text" id="messageText" autocomplete="off"/>
            <button>Send</button>
        </form>
        <ul id='messages'>
        </ul>
        <script>
            var ws = new WebSocket("ws://127.0.0.1:8000/chat_ws");
            ws.onmessage = function(event) {
                var messages = document.getElementById('messages')
                var message = document.createElement('li')
                var content = document.createTextNode(event.data)
                message.appendChild(content)
                messages.appendChild(message)
            };
            function sendMessage(event) {
                var input = document.getElementById("messageText")
                ws.send(input.value)
                input.value = ''
                event.preventDefault()
            }
        </script>
    </body>
</html>
"""


@app.get("/")
async def get():
    return HTMLResponse(html)

if __name__ == '__main__':
    uvicorn.run(app,host="0.0.0.0",port=8000)
