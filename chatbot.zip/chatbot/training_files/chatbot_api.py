import os
import joblib
import faiss
from langchain.chat_models import ChatOpenAI
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQAWithSourcesChain, LLMChain
from langchain.memory import ConversationBufferMemory
from langchain.chains.question_answering import load_qa_chain
from langchain import OpenAI
from langchain.sql_database import SQLDatabase
from langchain.agents import create_sql_agent
from langchain.agents.agent_types import AgentType
from langchain.prompts import ChatPromptTemplate
from langchain.llms import OpenAI as base_llm
from dotenv import load_dotenv
from pydantic import BaseModel
from fastapi import FastAPI, WebSocket, Request, Response, Form, Depends, UploadFile, File
import uvicorn

load_dotenv()

app = FastAPI()

class Query(BaseModel):
    Question : str

@app.post('/chat')
async def chatbot(query : Query):
    # try:
        question=query.Question
        print(question)
        if question=="":
            print("Refresh")
            return { 'data':[{
                    'question' : "Refresh",
                    'answer' : "How can I help You!",
                    'sources' : None
                }]}

        llm=ChatOpenAI(temperature=0, model_name='gpt-3.5-turbo')

        with open("PW_faiss_store_openai.pkl", "rb") as f:
            vectorStore_openAI = joblib.load(f)

        memory = ConversationBufferMemory(memory_key="chat_history",output_key="answer", input_key="question")

        chain = RetrievalQAWithSourcesChain.from_llm(llm=llm, retriever=vectorStore_openAI.as_retriever(), memory=memory)
        chain.return_source_documents=True
        ans=chain({"question": question}, return_only_outputs=True)

        print(ans)

        if ans['answer']== "I don't know.\n":
            return { 'data':[{
                    'question' : question,
                    'answer' : "Sorry I don't have any particular information about this, give some more insight or contact directly to property wallet help team.",
                    'sources' : None
                }]}
        else:
            return { 'data':[{
                    'question' : question,
                    'answer' : ans['answer'],
                    'sources' : ans['sources']
                }]}
            # return ans

    # except:
    #     return "An error occured"


@app.websocket("/chat_ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        print(data)
        await websocket.send_text(f"Message text was: {data}")


if __name__ == '__main__':
    uvicorn.run(app,host="0.0.0.0",port=8000)
