import os
from langchain.agents import create_sql_agent
from langchain.agents.agent_toolkits import SQLDatabaseToolkit
from langchain.llms.openai import OpenAI
from langchain.agents import AgentExecutor
from langchain.agents.agent_types import AgentType
from langchain.chat_models import ChatOpenAI
import os
import boto3
from langchain.sql_database import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from langchain.memory import ConversationBufferMemory
from langchain.chains import create_sql_query_chain
import uvicorn
import pandas as pd
import numpy as np
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File
from pydantic import BaseModel
from dotenv import load_dotenv
from langchain.agents import AgentType, initialize_agent, AgentExecutor

load_dotenv()
# os.environ["OPENAI_API_KEY"] = "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"

app = FastAPI()
class Query(BaseModel):
    Question : str

@app.post('/chat')
async def match(query : Query):
    userinfo = ', give data for user id 1'
    # tableinfo = """\nTables to look for data in are, user, lead, lead_inventory, lead_permission, view_inventory, view_listing_and_hot_listing, pw_assign_package, pw_package, pw_sub_package,
    # inventory, listing, hot_listing"""
    query=query.Question
    query=query+userinfo
    session = boto3.Session(aws_access_key_id='AKIAUCVMOYIN346USQP3', aws_secret_access_key='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')
    rds = session.client('rds',region_name='ap-south-1')
    endpoint = rds.describe_db_instances(DBInstanceIdentifier='karachihills')['DBInstances'][0]['Endpoint']['Address']
    print(endpoint)
    db1 = SQLDatabase.from_uri("postgresql://postgres:Panasonic1@"+endpoint+":5432/property_wallet")

    # llm = OpenAI(temperature=0)
    # db_chain = SQLDatabaseChain.from_llm(llm, db1)
    # db_chain = create_sql_query_chain(llm,db1)
    # ans=db_chain.invoke(query)

    # Total leads generated
    # views count
    # user count
    # package name
    # subciptioncharges
    # expiry
    # total staff and total managers
    # total inventories
    # total hot listing and normal listing
    # total refreshes
    toolkit1 = SQLDatabaseToolkit(db=db1, llm=OpenAI(temperature=0))
    agent_executor = create_sql_agent(
        llm=OpenAI(temperature=0,  model_name='gpt-3.5-turbo-16k'),
        toolkit=toolkit1,
        verbose=True,
        agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        max_iterations=30,
        early_stopping_method="generate",
        handle_parsing_errors=True,
    )
    ans=agent_executor.run(query)
    # print(ans)
    # return { 'data':[{
    #                 'question' : query,
    #                 'answer' : ans['answer'],
    #                 'sources' : None
    #             }]}
    return ans

if __name__ == '__main__':
    uvicorn.run(app,host="127.0.0.2",port=8000)
