import joblib
import faiss
from langchain.chat_models import ChatOpenAI
from langchain.vectorstores import FAISS
from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate, MessagesPlaceholder
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.memory import ConversationBufferMemory
from dotenv import load_dotenv
from pydantic import BaseModel
from fastapi import FastAPI, WebSocket
import uvicorn
import re
import asyncio
import threading
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
# from langchain_core.messages import AIMessage, HumanMessage, BaseMessage
# from langchain_core.output_parsers import StrOutputParser
# from langchain.chains.conversational_retrieval.prompts import CONDENSE_QUESTION_PROMPT,QA_PROMPT

load_dotenv()

app = FastAPI()
def initialize_retrieval_chain():
    llm=ChatOpenAI(streaming=True, callbacks=[StreamingStdOutCallbackHandler()], temperature=0, model_name='gpt-3.5-turbo')
    with open("data/PW_faiss_store_openai_linux.pkl", "rb") as f:
        vectorStore_openAI = joblib.load(f)

    prompt = ChatPromptTemplate.from_messages(
        [
            SystemMessagePromptTemplate.from_template(
                    """
                    You are an AI assistant and your name is 'Humza, The Property Ustaad'.
                    You are responsible for answering to user query/questions.
                    {context}
                    """
            ),
            HumanMessagePromptTemplate.from_template(
                # """
                # Current conversation:
                # {chat_history}
                """
                Human: {question}
                AI Assistant:
                """
            )
        ]
    )
    
    # memory=ConversationBufferMemory(ai_prefix="AI Assistant",memory_key='chat_history',return_messages=True)
    # retrieval_chain = ConversationalRetrievalChain.from_llm(memory=memory,llm=llm, retriever=vectorStore_openAI.as_retriever(),chain_type='stuff',combine_docs_chain_kwargs={'prompt': prompt})
    retrieval_chain = ConversationalRetrievalChain.from_llm(llm=llm, retriever=vectorStore_openAI.as_retriever(),chain_type='stuff',combine_docs_chain_kwargs={'prompt': prompt})

    retrieval_chain.return_source_documents=False
    print("retrieval unit initialized")
    return retrieval_chain

retrieval_chain = initialize_retrieval_chain()

# def get_chat_history(chat_history):
#     history=[]
#     for pair in chat_history:
#         # history.append([pair[0],pair[1]])
#         history.append(BaseMessage(content=pair[0],type='human'))
#         history.append(BaseMessage(content=pair[1],type='ai'))        
#     return history

async def background_task(websocket : WebSocket, Client_id : int, data : str):
    try:
        question=data
        print("User",Client_id,":",question)
        if question=="First Time":
            print("Refresh")
            output = "How can I help You!"

        else:
            # print(chat_history[Client_id])
            output=retrieval_chain.run({'question':question,'chat_history':[]})
            # output=retrieval_chain.run({'question':question,'chat_history':chat_history[Client_id]})
            # output=retrieval_chain.run({'question':question,'chat_history':get_chat_history(chat_history[Client_id])})
            chat_history[Client_id].append((question,output))

        if 'Answer:' in output:
            output=output.replace('Answer:','')
        elif 'Humza:' in output:
            output=output.replace('Humza:','')
        elif 'Assistant:' in output:
            output=output.replace('Assistant:','')
        elif 'Humza, The Property Ustaad:' in output:
            output=output.replace('Humza, The Property Ustaad:','')


        print("\nBot to User",Client_id,":",output)
        if re.sub("[ ]","",output)=="Agentstoppedduetoiterationlimitortimelimit.":
            await websocket.send_json({
                                    'data':[{
                                    'question' : question,
                                    'answer' : "Something went wrong.",
                                    }]
                                })

        else:
            await websocket.send_json({
                                        'data':[{
                                        'question' : question,
                                        'answer' : re.sub("[()]","",output),
                                        }]
                                    })

    except:
        await websocket.send_json({
                                    'data':[{
                                    'question' : question,
                                    'answer' : "Something went wrong.",
                                    }]
                                })

class Query(BaseModel):
    Question : str

@app.get('/health-check')
def hello():
    return {"message" : 'health-check'}

def thread_function(websocket : WebSocket, Client_id, data):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(background_task(websocket, Client_id, data))


chat_history={}
@app.websocket("/chat_ws/{Client_id}")
async def websocket_endpoint(websocket: WebSocket, Client_id : int):
    await websocket.accept()
    chat_history[Client_id]=[]
    while True:
        data = await websocket.receive_text()
        thread = threading.Thread(target=thread_function,args=(websocket, Client_id, data))
        thread.start()


if __name__ == '__main__':
    uvicorn.run(app,host="0.0.0.0",port=3000)#,ssl_keyfile="localhost+2-key.pem",ssl_certfile="localhost+2.pem")
