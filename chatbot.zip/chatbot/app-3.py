import os
import joblib
import faiss
from langchain.chat_models import ChatOpenAI
from langchain.vectorstores import FAISS
from langchain.chains import RetrievalQAWithSourcesChain, LLMChain, ConversationalRetrievalChain
from langchain.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from langchain.memory import ConversationBufferMemory
from langchain.llms import OpenAI
from langchain.sql_database import SQLDatabase
from langchain.agents import create_sql_agent, ZeroShotAgent
from langchain.agents import AgentType, initialize_agent, AgentExecutor
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate
from langchain.schema.messages import SystemMessage
from langchain.tools import BaseTool, StructuredTool, Tool, tool
from langchain.agents.agent_toolkits import SQLDatabaseToolkit
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from typing import Annotated
from fastapi import Depends, FastAPI, WebSocket, HTTPException, status
import uvicorn
from fastapi.responses import HTMLResponse
import re
import asyncio
import threading

load_dotenv()

app = FastAPI()

# def initialize_conversational_chain():
#     chat_template = ChatPromptTemplate.from_messages(
#         [
#             SystemMessage(
#                 content=(
#                     "You are an AI assitant 'Humza The Property Ustaad'."
#                     "You are a helpful assistant that respond to user's text and does a friendly conversation with user."
#                     "Only be limited to normal chatting"
#                     "Answer 'I don't know' to questions that required additional information about place, person or thing other than questions that refer to you."
#                 )
#             ),
#             HumanMessagePromptTemplate.from_template("{text}"),
#         ]
#     )
#     llm=ChatOpenAI(temperature=1, model_name='gpt-3.5-turbo')
#     conversational_chain = LLMChain(llm=llm,prompt=chat_template,memory=ConversationBufferMemory())
#     print("conversational unit initialized")
#     return conversational_chain

def initialize_retrieval_chain():
    llm=ChatOpenAI(streaming=True, callbacks=[StreamingStdOutCallbackHandler()], temperature=0, model_name='gpt-3.5-turbo')
    # llm=ChatOpenAI(temperature=0, model_name='gpt-3.5-turbo')
    with open("data/PW_faiss_store_openai_linux.pkl", "rb") as f:
        vectorStore_openAI = joblib.load(f)

    # retrieval_chain = RetrievalQAWithSourcesChain.from_llm(llm=llm, retriever=vectorStore_openAI.as_retriever())
    retrieval_chain = ConversationalRetrievalChain.from_llm(llm=llm, retriever=vectorStore_openAI.as_retriever())

    retrieval_chain.return_source_documents=False
    print("web retrieval unit initialized")
    return retrieval_chain


# conversational_chain = initialize_conversational_chain()
retrieval_chain = initialize_retrieval_chain()


async def background_task1(websocket : WebSocket, Client_id : int, data : str):
    try:
        question=data
        print("User",Client_id,":",question)
        if question=="First Time":
            print("Refresh")
            output = "How can I help You!"

        else:
            chat_history=[]
            output=retrieval_chain.run({'question':question,'chat_history':chat_history})

        print("\nBot to User",Client_id,":",output)
        if re.sub("[ ]","",output)=="Agentstoppedduetoiterationlimitortimelimit.":
            await websocket.send_json({
                                    'data':[{
                                    'question' : question,
                                    'answer' : "Something went wrong.",
                                    }]
                                })

        else:
            await websocket.send_json({
                                        'data':[{
                                        'question' : question,
                                        'answer' : re.sub("[()]","",output),
                                        }]
                                    })

    except:
        await websocket.send_json({
                                    'data':[{
                                    'question' : question,
                                    'answer' : "Something went wrong.",
                                    }]
                                })


async def background_task(websocket : WebSocket, Client_id : int, data : str):
        try:
            question=data
            print("User",Client_id,":",question)
            if question=="First Time":
                print("Refresh")
                output = "How can I help You!"

            else:
                multi_tools = [
                    # Tool.from_function(
                    #     func = conversational_chain.run,
                    #     name = "chit chat",
                    #     description = (
                    #             "You are an AI assitant 'Humza The Property Ustaad'."
                    #             "As an AI assistant you should respond to user's text and does a friendly conversation with user."
                    #             "You should only limit yourself to normal chatting"
                    #             ),
                    #     return_direct = True
                    # ),
                    Tool.from_function(
                        func = retrieval_chain,
                        name = "Information retriever",
                        description = (
                            "Useful for retrieving information and answering to FAQs about property wallet, provide appropiate links where useful."
                            "Answer 'I don't know' to questions that required additional information about place, person or thing other than questions that refers to property wallet"
                            "generate answer upto 100 words"
                            )
                    ),
                ]

                prefix = """Have a conversation with a human, answering the following questions as best you can. You have access to the following tools:"""
                suffix = """Begin!"

                        {chat_history}
                        Question: {input}
                        {agent_scratchpad}"""

                prompt = ZeroShotAgent.create_prompt(
                        multi_tools,
                        prefix=prefix,
                        suffix=suffix,
                        input_variables=["input", "chat_history", "agent_scratchpad"],
                    )

                # agent_llm = ChatOpenAI(model="gpt-3.5-turbo")
                agent_llm = LLMChain(llm=ChatOpenAI(model="gpt-3.5-turbo"), prompt=prompt)
                # agent = initialize_agent(tools=multi_tools, llm=agent_llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, handle_parsing_errors=True)
                agent = ZeroShotAgent(llm_chain=agent_llm, tools=multi_tools, verbose=True)
                # agent_chain = AgentExecutor.from_agent_and_tools(agent=agent, tools=multi_tools, verbose=True, memory=ConversationBufferMemory())
                agent_chain = AgentExecutor(agent=agent,tools=multi_tools,memory=ConversationBufferMemory(memory_key='chat_history'),handle_parsing_errors=True, max_iterations=5)#, early_stopping_method='generate')#,max_execution_time=10.0,)
                # output = agent_chain.run(question)
                output=agent_chain.run(input=question)

            print("\nBot to User",Client_id,":",output)
            if re.sub("[ ]","",output)=="Agentstoppedduetoiterationlimitortimelimit.":
                await websocket.send_json({
                                        'data':[{
                                        'question' : question,
                                        'answer' : "Something went wrong.",
                                        }]
                                    })

            await websocket.send_json({
                                        'data':[{
                                        'question' : question,
                                        'answer' : re.sub("[()]","",output),
                                        }]
                                    })

        except:
            await websocket.send_json({
                                        'data':[{
                                        'question' : question,
                                        'answer' : "Something went wrong.",
                                        }]
                                    })

class Query(BaseModel):
    Question : str

@app.get('/health-check')
def hello():
    return {"message" : 'health-check'}

def thread_function(websocket : WebSocket, Client_id, data):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    # loop.run_until_complete(background_task(websocket, Client_id, data))
    loop.run_until_complete(background_task(websocket, Client_id, data))


@app.websocket("/chat_ws/{Client_id}")
async def websocket_endpoint(websocket: WebSocket, Client_id : int):
    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        thread = threading.Thread(target=thread_function,args=(websocket, Client_id, data))
        thread.start()


if __name__ == '__main__':
    uvicorn.run(app,host="0.0.0.0",port=3000)#,ssl_keyfile="localhost+2-key.pem",ssl_certfile="localhost+2.pem")
