from fastapi import FastAPI, WebSocket, Form, Depends, UploadFile, File
import cv2 
from facenet_pytorch import MTCNN
import torch
import numpy as np
import threading
import uvicorn
from PIL import Image
import json
import io
from deepface import DeepFace

app=FastAPI()

@app.get('/health-check')
def health_check():
    return "hello world"

left_offset = 20
fontScale = 2
fontThickness = 3
text_color = (0,0,255)
lineColor = (255, 255, 0)

device = torch.device('cpu')
# print(f'Running on device: {device}')

mtcnn = MTCNN(image_size=160,
              margin=0,
              min_face_size=20,
              thresholds=[0.6, 0.7, 0.7], # MTCNN thresholds
              factor=0.709,
              post_process=True,
              device=device # If you don't have GPU
        )

def npAngle(a, b, c):
    ba = a - b
    bc = c - b 
    
    cosine_angle = np.dot(ba, bc)/(np.linalg.norm(ba)*np.linalg.norm(bc))
    angle = np.arccos(cosine_angle)
    
    return np.degrees(angle)

def predFacePose(frame:bytes):
    try:
        frame = np.asarray(bytearray(frame), dtype="uint8")
        frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
        bbox_, prob_, landmarks_ = mtcnn.detect(frame, landmarks=True) # The detection part producing bounding box, probability of the detected face, and the facial landmarks
        angle_R_List = []
        angle_L_List = []
        predLabelList = []
        try:
            for bbox, landmarks, prob in zip(bbox_, landmarks_, prob_):
                if bbox is not None: # To check if we detect a face in the image
                    print(prob)
                    midpoint=[(landmarks[0][0]+landmarks[1][0])/2,(landmarks[0][1]+landmarks[1][1])/2]
                    Area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
                    print(Area)
                    min_distace = 80000
                    max_distnace = 100000
                    if int(Area) in range(min_distace,max_distnace):
                        if prob > 0.8: # To check if the detected face has probability more than 90%, to avoid 
                            angR = npAngle(landmarks[0], landmarks[1], landmarks[2]) # Calculate the right eye angle
                            angL = npAngle(landmarks[1], landmarks[0], landmarks[2])# Calculate the left eye angle
                            angle_R_List.append(angR)
                            angle_L_List.append(angL)
                            print(angR,angL)
                            if ((int(angR) in range(35, 57)) and (int(angL) in range(35, 58))):
                                predLabel='Frontal'
                                predLabelList.append(predLabel)
                            else: 
                                if angR < angL: predLabel='Left Profile'
                                else: predLabel='Right Profile'
                                predLabelList.append(predLabel)
                            
                            return predLabelList
                        else:
                            return "Face detected with low accuracy"
                    else:
                        if int(Area)<min_distace: return "Come close"
                        if int(Area)>=max_distnace: return "Go far"
                else:
                    return "No Face"
        except:
            return "No Face"
    except:
        return "No Image"

@app.websocket('/check_angle')
async def check_angle(websocket:WebSocket):#, frame : UploadFile = File()):
    await websocket.accept()
    while True:
        frame=await websocket.receive_bytes()
        result=predFacePose(websocket,frame)
        print(result)
        await websocket.send_json({
            'result': result
        })
        # thread=threading.Thread(target=predFacePose,args=(websocket,frame))
        # thread.start()
        

@app.post("/checkin")
async def verify_images(img1: UploadFile = File(...), img2: UploadFile = File(...)):
    try:
        img1_bytes = await img1.read()
        image1_bytes_stream = io.BytesIO(img1_bytes)
        image1 = Image.open(image1_bytes_stream)
        np_img1 = np.array(image1)

        img2_bytes = await img2.read()
        image2_bytes_stream = io.BytesIO(img2_bytes)
        image2 = Image.open(image2_bytes_stream)
        np_img2 = np.array(image2)

        result = DeepFace.verify(img1_path=np_img1, img2_path=np_img2, model_name="Facenet512", detector_backend="mediapipe")
        print("result : ",result)
        result_json = json.dumps(result)
        return result

    except:
        return {"message":"error"}
    

if __name__ == '__main__':
    uvicorn.run(app)