from fastapi import FastAPI, WebSocket, Form, Depends, UploadFile, File
import cv2 
from facenet_pytorch import MTCNN
import torch
import numpy as np
import threading
import uvicorn
import base64

app=FastAPI()

@app.get('/health-check')
async def health_check():
    return "hello world"

left_offset = 20
fontScale = 2
fontThickness = 3
text_color = (0,0,255)
lineColor = (255, 255, 0)

# device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
# print(f'Running on device: {device}')
device =  torch.device('cpu')

mtcnn = MTCNN(image_size=160,
              margin=0,
              min_face_size=20,
              thresholds=[0.6, 0.7, 0.7], # MTCNN thresholds
              factor=0.709,
              post_process=True,
              device=device # If you don't have GPU
        )

def npAngle(a, b, c):
    ba = a - b
    bc = c - b     
    cosine_angle = np.dot(ba, bc)/(np.linalg.norm(ba)*np.linalg.norm(bc))
    angle = np.arccos(cosine_angle)
    return np.degrees(angle)

def euclidean(a,b):
    return np.linalg.norm(a-b)

def area(bbox):
    return (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])

def Midpoint(left,right):
    return [(left[0]+right[0])/2,(left[1]+right[1])/2]

def predFacePose(frame:bytes):
    try:
        frame = np.asarray(bytearray(frame), dtype="uint8")
        frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
        cv2.imwrite("he.jpg",frame)
        bbox_, prob_, landmarks_ = mtcnn.detect(frame, landmarks=True)
        angle_R_List = []
        angle_L_List = []
        predLabelList = []
        min_distace = 95000
        max_distnace = 180000
        try:
            for bbox, landmarks, prob in zip(bbox_, landmarks_, prob_):
                if bbox is not None:
                    midpoint=Midpoint(landmarks[0],landmarks[1])
                    Area = area(bbox)
                    print("Face Distance: ",Area)
                    if int(Area) in range(min_distace,max_distnace):
                        if prob > 0.8: 
                            angR = npAngle(landmarks[0], landmarks[1], landmarks[2])
                            angL = npAngle(landmarks[1], landmarks[0], landmarks[2])
                            angMidR = npAngle(landmarks[1], midpoint, landmarks[2])
                            angMidL = npAngle(landmarks[0], midpoint, landmarks[2])
                            MidnoseDist = euclidean(midpoint,landmarks[2])
                            angle_R_List.append(angR)
                            angle_L_List.append(angL)
                            if ((int(angR) in range(35, 57)) and (int(angL) in range(35, 58))):
                                if((int(angMidR) in range(80, 100)) and (int(angMidL) in range(80, 100))):
                                    if MidnoseDist>120: predLabel="Down"
                                    elif MidnoseDist<50: predLabel="Up"
                                    else: predLabel='Front'
                                else:
                                    predLabel='Front'
                            elif((int(angMidR) in range(80, 100)) and (int(angMidL) in range(80, 100))):
                                if MidnoseDist>120: predLabel="Down"
                                elif MidnoseDist<50: predLabel="Up"
                            else: 
                                if angR < angL: predLabel='Left'
                                else: predLabel='Right'
                            print("Mid nose dist: ",MidnoseDist)
                            print("Angle right: ",angR)
                            print("Angle left: ",angL)
                            print("Midpoint right angle: ",angMidR)
                            print("Midpoint left angle: ",angMidL)
                        else:
                            predLabel="Face detected with low accuracy"
                    else:
                        if int(Area)<min_distace: predLabel="Come close"
                        if int(Area)>=max_distnace: predLabel="Go far"
                else:
                    predLabel="No Face"
                predLabelList.append(predLabel)
                return predLabelList
        except:
            predLabel="No Face"
    except:
        predLabel="No Image"
    return [predLabel]
    

@app.websocket('/check_angle')
async def check_angle(websocket:WebSocket):
    await websocket.accept()
    while True:
        frame=await websocket.receive_bytes()
        result=predFacePose(frame)
        print("Result: ",result)
        encoded_image = base64.b64encode(frame).decode('utf-8')
        await websocket.send_json(
            {
            'result': result,
            'image': encoded_image
            },
        )
        # thread=threading.Thread(target=predFacePose,args=(websocket,frame))
        # thread.start()
        
    
if __name__ == '__main__':
    uvicorn.run(app,host="0.0.0.0",port=5000)