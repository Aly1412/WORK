# import websockets 
import asyncio
import cv2
import tracemalloc
import numpy as np
import base64
from fastapi.websockets import WebSocket
import websockets

async def Forward():
    #     image1 = np.asarray(bytearray(image_bytes), dtype="uint8")
    #     image1 = cv2.imdecode(image1, cv2.IMREAD_COLOR)
    url = 'ws://192.168.18.90:8000/check_angle'
    websocket = WebSocket(url)
    try:
        video_cap = cv2.VideoCapture(0)
        win_name = 'Video Preview'
        cv2.namedWindow(win_name)
        # video_cadesired_width = 160
        # desired_height = 160
        # dim = (desired_width, desired_height)
        # left_offset = 20
        # fontScale = 2
        # fontThickness = 3
        # text_color = (0,0,255)
        while True:
            has_frame, frame = video_cap.read()
            if not has_frame:
                break
            
            cv2.imwrite('hello.jpg',frame)
            # print(response)
            with open('hello.jpg', 'rb') as file:
                image_bytes = file.read()
                base64_encoded_string = base64.b64encode(image_bytes).decode('utf-8')
                await websocket.send_bytes(base64_encoded_string)
        
            key = cv2.waitKey(1)

            if key == ord('Q') or key == ord('q') or key == 27:
                break
            
        video_cap.release()
        cv2.destroyWindow(win_name)
    
    except:
        print('hello')
            

    
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
loop.run_until_complete(Forward())


