from facenet_pytorch import MTCNN
from PIL import Image
from matplotlib import pyplot  as plt
import numpy as np
import math
import requests
import argparse
import torch
import cv2

parser = argparse.ArgumentParser("Face pose detection for one face")
parser.add_argument("-p", "--path", help="To use image path.", type=str)
parser.add_argument("-u", "--url", help="To use image url", type=str)
args = parser.parse_args()

path = args.path
url = args.url

left_offset = 20
fontScale = 2
fontThickness = 3
text_color = (0,0,255)
lineColor = (255, 255, 0)

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print(f'Running on device: {device}')

mtcnn = MTCNN(image_size=160,
              margin=0,
              min_face_size=20,
              thresholds=[0.6, 0.7, 0.7], 
              factor=0.709,
              post_process=True,
              device=device 
        )

# Landmarks: [Left Eye], [Right eye], [nose], [left mouth], [right mouth]
def npAngle(a, b, c):
    ba = a - b
    bc = c - b 
    
    cosine_angle = np.dot(ba, bc)/(np.linalg.norm(ba)*np.linalg.norm(bc))
    angle = np.arccos(cosine_angle)
    degrees = np.degrees(angle)
    return degrees


def predFacePose(frame):
    
    bbox_, prob_, landmarks_ = mtcnn.detect(frame, landmarks=True) # The detection part producing bounding box, probability of the detected face, and the facial landmarks
    angle_R_List = []
    angle_L_List = []
    angle_U_List = []
    predLabelList = []
    
    for bbox, landmarks, prob in zip(bbox_, landmarks_, prob_):
        print(landmarks[0], landmarks[1], landmarks[2])

        midpoint = ((landmarks[0][0] + landmarks[1][0])/2) , ((landmarks[0][1] + landmarks[1][1])/2)
        print("MidPoint : ",midpoint) 
    
        if bbox is not None: 
            if prob > 0.9: # To check if the detected face has probability more than 90%, to avoid 
                angR = npAngle(landmarks[0], landmarks[1], landmarks[2]) # Calculate the right eye angle
                angL = npAngle(landmarks[1], landmarks[0], landmarks[2])# Calculate the right eye angle
                angU = npAngle(landmarks[0], landmarks[2], landmarks[1]) # Calculate the left eye angle
                print(angR, angL,angU)
                angle_R_List.append(angR)
                angle_L_List.append(angL)
                angle_U_List.append(angU)
                if ((int(angR) in range(35, 57)) and (int(angL) in range(35, 58))):
                # if (((abs(int(angR) - int(angL))) <= range(2,5))):
                    predLabel='Frontal'
                    predLabelList.append(predLabel)
                # elif ((int(angR) in range(35, 57)) and (int(angL) in range(35, 58))):
                #     predLabel='Frontal'
                #     predLabelList.append(predLabel)
                else: 
                    if angR < angL:
                        predLabel='Left Profile'
                    else:
                        predLabel='Right Profile'
                    predLabelList.append(predLabel)
            else:
                print('The detected face is Less then the detection threshold')
        else:
            print('No face detected in the image')
    return landmarks_, angle_R_List, angle_L_List, predLabelList
    

def predFacePoseApp(path, url):
    if path is not None:
        try:
            im = Image.open(path)
            if im.mode != "RGB": # Convert the image if it has more than 3 channels, because MTCNN does not accept more than 3 channels.
                im = im.convert('RGB')
            predLabelList = predFacePose(im)
        except Exception as e:
            return print(f"Issue with image path: {e}")
    elif url is not None:
        try:
            im = Image.open(requests.get(url, stream=True).raw)
            if im.mode != "RGB": # Convert the image if it has more than 3 channels, because MTCNN does not accept more than 3 channels.
                im = im.convert('RGB')
            predLabelList = predFacePose(im)  
        except Exception as e:
            return print(f"Issue with image URL: {e}")
    else:
        # source = 0
        video_cap = cv2.VideoCapture(0)
        win_name = 'Video Preview'
        cv2.namedWindow(win_name)
        # video_cadesired_width = 160
        # desired_height = 160
        # left_offset = 20
        # fontScale = 2
        # fontThickness = 3
        # text_color = (0,0,255)
        while True:
            
            has_frame, frame = video_cap.read()
            if not has_frame:
                break
            
            predLabelList = predFacePose(frame)
            print(predLabelList)

            key = cv2.waitKey(1)

            if key == ord('Q') or key == ord('q') or key == 27:
                break

        video_cap.release()
        cv2.destroyWindow(win_name)
        pass

if __name__ == '__main__':
    predFacePoseApp(path, url)