from fastapi import FastAPI, File, UploadFile
from PIL import Image
import json
import numpy as np
import io
import uvicorn
from deepface import DeepFace

app = FastAPI()

@app.post("/video_feed")
async def verify_images(img1: UploadFile = File(...), img2: UploadFile = File(...)):
    try:
        img1_bytes = await img1.read()
        image1_bytes_stream = io.BytesIO(img1_bytes)
        image1 = Image.open(image1_bytes_stream)
        np_img1 = np.array(image1)

        img2_bytes = await img2.read()
        image2_bytes_stream = io.BytesIO(img2_bytes)
        image2 = Image.open(image2_bytes_stream)
        np_img2 = np.array(image2)

        result = DeepFace.verify(img1_path=np_img1, img2_path=np_img2, model_name="Dlib", detector_backend="ssd")
        print("result : ",result)
        result_json = json.dumps(result)
        return result

    except:
        return {"message":"error"}

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=3000)
