import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from dotenv import load_dotenv
import faiss
import joblib
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQAWithSourcesChain, RetrievalQA
from langchain.vectorstores import FAISS
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, PromptTemplate
from langchain.schema.messages import SystemMessage
import pandas as pd
# from mangum import Mangum

load_dotenv()

# handler = Mangum(app)

app=FastAPI()

#=========================================================Enhancing API
@app.get('/enchance_title')
async def enchance_title(title : str):
    prompt_template = """You have to transform user's input to a better title, making it grammatically right and more appropriate.
                    If user input is in Urdu(Roman) then return transformed text also in Urdu(Roman).
                    For your reference provided are the examples of how you can transform user input.
                    If you are unable understand user input then do not transform user input and only return 'Nothing'.

                    {context}

                    Question: {question}
                    Answer after transforming:"""

    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context","question"]
    )

    chain_type_kwargs = {"prompt": PROMPT}

    with open("data/title_data.pkl", "rb") as f:
        vectorStore_openAI = joblib.load(f)

    retrieval_chain = RetrievalQA.from_chain_type(llm=ChatOpenAI(), chain_type="stuff", retriever=vectorStore_openAI.as_retriever(), chain_type_kwargs=chain_type_kwargs)
    output=retrieval_chain.run(title)
    print(output)

    if output == 'Nothing':
        output = title

    return {
    'data':
        [
            {'transformed':output}
        ]
    }


@app.get('/enchance_description')
async def enchance_description(description : str):
    prompt_template = """You have to transform user's input to a better description, making it grammatically right and more appropriate.
                    If user input is in Urdu(Roman) then return transformed text also in Urdu(Roman).
                    For your reference provided are the examples of how you can transform user input.
                    If you are unable understand user input then do not transform user input and only return 'Nothing'.
                    {context}

                    Question: {question}
                    Answer after transforming:"""

    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context","question"]
    )

    chain_type_kwargs = {"prompt": PROMPT}

    with open("data/description_data.pkl", "rb") as f:
        vectorStore_openAI = joblib.load(f)

    retrieval_chain = RetrievalQA.from_chain_type(llm=ChatOpenAI(), chain_type="stuff", retriever=vectorStore_openAI.as_retriever(), chain_type_kwargs=chain_type_kwargs)
    output=retrieval_chain.run(description)

    if output == 'Nothing':
        output = description

    return {
        'data':
            [
                {'transformed':output}
            ]
    }


if __name__ == '__main__':
    uvicorn.run(app)
