import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from pydantic import BaseModel
from fastapi.logger import logger
from fastapi.security import OAuth2PasswordBearer
from tensorflow.keras.models import load_model
import pickle
import joblib
import transformers
from transformers import BertConfig, BertTokenizerFast, TFBertModel
from transformers import AdamW
import numpy as np
import psycopg2
import os
import datetime
from dotenv import load_dotenv
import requests
import cv2 as cv
import pandas as pd
# from mangum import Mangum

load_dotenv()

bert = TFBertModel.from_pretrained('bert')
tokenizer = BertTokenizerFast.from_pretrained('bert')

app=FastAPI()

# handler = Mangum(app)

@app.get('/health-check')
def hello():
    return {"message" : 'health-check'}

def initiate_dbaccess():
    DB_NAME = os.environ["DB_NAME"]
    DB_USER = os.environ["DB_USER"]
    DB_PASS = os.environ["DB_PASS"]
    DB_HOST = os.environ["DB_HOST"]
    DB_PORT = os.environ["DB_PORT"]

    conn = psycopg2.connect(database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)
    return conn

def tokenization(title):
    X_tokenize=tokenizer([title], max_length=25, pad_to_max_length=True, truncation=True, return_tensors="tf")
    return X_tokenize

def get_bert_embeddings(X_tokenize):
    bert_output = bert([X_tokenize['input_ids'],X_tokenize['token_type_ids'],X_tokenize['attention_mask']])
    return bert_output

def get_bert_prediction(bert_output,path):
    bert_model=load_model(path)
    bert_model.compile(optimizer="Adam", loss="CategoricalCrossentropy", metrics=["accuracy"])
    predictions=bert_model.predict(np.array(bert_output.last_hidden_state).tolist())
    predictions=predictions[0].round(1)
    mx=predictions.max()
    predictions=list(predictions)
    Class=predictions.index(mx)+1
    return Class

def get_mobilenet_prediction(photos):
    mobilenet_model=load_model('models/softmax_mobilenet_v3.h5')
    c_good=0
    c_bad=0
    count=0
    for photo in photos:
        print(photo)
        r = requests.get(photo, allow_redirects=True)
        open('temp'+str(count)+'.jpeg', 'wb').write(r.content)
        img=cv.imread('temp'+str(count)+'.jpeg')
        count=count+1
        img=cv.resize(img,(224,224))
        predictions=mobilenet_model.predict(np.array([img]).tolist())
        predictions=predictions[0].round(1)
        mx=predictions.max()
        predictions=list(predictions)
        photo_class=predictions.index(mx)+1
        if photo_class==1:
            c_good=c_good+1
        else:
            c_bad=c_bad+1
    print("======get ready for your grades======")
    if c_good==c_bad:
        return 2
    elif c_good>c_bad:
        return 1
    else:
        return 3

def save_grade_to_db(record):
    conn=initiate_dbaccess()
    cur = conn.cursor()
    cur.execute("""SELECT * FROM inventory_grading as IG WHERE IG."inventoryId"=(%s) """,(record['inv'],))
    if cur.fetchall()==[]:
        print('record doesnt exist')
        cur = conn.cursor()
        cur.execute("""INSERT INTO inventory_grading ("inventoryId","grade","titleRating","descriptionRating","photosRating") VALUES (%s,%s,%s,%s,%s) """,
                    (record['inv'],record['grade'],record['title'],record['description'],record['photos']))
        conn.commit()
        conn.close()
    else:
        print('record exist')
        cur = conn.cursor()
        cur.execute("""UPDATE inventory_grading SET "grade"=%s,"titleRating"=%s,"descriptionRating"=%s,"photosRating"=%s,"updatedAt"=%s WHERE "inventoryId"=%s """,
                    (record['grade'],record['title'],record['description'],record['photos'],datetime.datetime.now(),record['inv']))
        conn.commit()
        conn.close()
    return


#=========================================================Getting Predictions
@app.get("/title_prediction")
async def title_prediction(title : str):
    print(title)
    classes=['good','average','bad']
    X_tokenize=tokenization(title)
    bert_output=get_bert_embeddings(X_tokenize)
    title_class=get_bert_prediction(bert_output,'models/titles_bert_v2.h5')
    return {
        'data':
            [
                {'rating':classes[title_class-1]}
            ]
        }

@app.get("/description_prediction")
async def title_prediction(description : str):
    print(description)
    classes=['good','average','bad']
    X_tokenize=tokenization(description)
    bert_output=get_bert_embeddings(X_tokenize)
    description_class=get_bert_prediction(bert_output,'models/descriptions_bert_v5.h5')
    return {
        'data':
            [
                {'rating':classes[description_class-1]}
            ]
        }

#=========================================================Grading API
class inventory(BaseModel):
    Inv_id : int
    title : str
    description : str
    photos : list

@app.post('/grade_listing')
def grade(Inventory : inventory):
    Inv_id = Inventory.Inv_id
    title = Inventory.title
    description = Inventory.description
    photos = Inventory.photos

    print(Inv_id)
    print(title)
    print(description)
    print(photos)

    classes=['good','average','bad']

    #title classification
    X_tokenize=tokenization(title)
    bert_output=get_bert_embeddings(X_tokenize)
    title_class=get_bert_prediction(bert_output,'models/titles_bert_v2.h5')

    #description classification
    X_tokenize=tokenization(description)
    bert_output=get_bert_embeddings(X_tokenize)
    description_class=get_bert_prediction(bert_output,'models/descriptions_bert_v5.h5')

    #photos classification
    photo_class=get_mobilenet_prediction(photos)
    #grading
    inference=[title_class,description_class,photo_class]

    model=joblib.load('models/grade_DT.pkl')
    pred=model.predict([inference])

    grade=['A','B','C','D']
    if pred[0] in [1,2]:
        response={
            'inv':Inv_id,
            'status':'pass',
            'grade':grade[pred[0]-1],
            'title':classes[title_class-1],
            'description':classes[description_class-1],
            'photos':classes[photo_class-1]
            }
        save_grade_to_db(response)
        return response
    else:
        response={
            'inv':Inv_id,
            'status':'fail',
            'grade':grade[pred[0]-1],
            'title':classes[title_class-1],
            'description':classes[description_class-1],
            'photos':classes[photo_class-1]
            }
        save_grade_to_db(response)
        return response

if __name__ == '__main__':
    # bert = TFBertModel.from_pretrained('bert-base-uncased')
    # tokenizer = BertTokenizerFast.from_pretrained('bert-base-uncased')
    # config = bert.config
    # bert.save_pretrained('bert')
    # tokenizer.save_pretrained('bert')
    # config.save_pretrained('bert')
    uvicorn.run(app)
