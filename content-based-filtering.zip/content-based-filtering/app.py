import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from fastapi.logger import logger
from fastapi.security import OAuth2PasswordBearer
import numpy as np
import pandas as pd
import os
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, concatenate, Flatten
from tensorflow.keras.models import load_model
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv
import psycopg2
from numpy import save
from numpy import load
# import pickle5 as pickle
from json import loads, dumps
import jwt
import boto3
from sklearn.cluster import KMeans
import joblib
import math
from typing import Optional
from fastapi_pagination import Page, paginate, add_pagination, Params
from pydantic import BaseModel
from fastapi_pagination.utils import disable_installed_extensions_check
from mangum import Mangum

disable_installed_extensions_check()

load_dotenv()

session = boto3.Session(aws_access_key_id=os.environ["aws_access_key_id"], aws_secret_access_key=os.environ["aws_secret_access_key"])
s3 = session.resource('s3')
s3_client = session.client('s3')

app = FastAPI(
    # docs_url=None,
    # redoc_url=None,
)
handler = Mangum(app)

class Inventory(BaseModel):
    id: int
    title: str
    description: str
    price: np.double
    projectSubTypeId: int
    projectId: int
    landSize: int
    landAreaId: int
    noOfUnit: int
    noOfSold: int
    inVentoryType: str
    category: str
    sub_category: str
    saleCommission: int
    agencyId: int
    city: str
    address: str
    land_title: str
    type: str
    photos: list[str]

@app.get('/health-check')
async def healthCheck():
    return Response(content="hello world")

def initiate_dbaccess():
    DB_NAME = os.environ["DB_NAME"]
    DB_USER = os.environ["DB_USER"]
    DB_PASS = os.environ["DB_PASS"]
    DB_HOST = os.environ["DB_HOST"]
    DB_PORT = os.environ["DB_PORT"]

    conn = psycopg2.connect(database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)

    return conn

def get_model(text_matrix1,text_matrix2,text_matrix3,text_matrix4,numeric_max_scaled,tokenizer1,tokenizer2,tokenizer3,tokenizer4):
    input_text1 = Input(shape=(text_matrix1.shape[1],))
    embedding_layer1 = Embedding(input_dim=len(tokenizer1.word_index) + 1, output_dim=16)(input_text1)
    flatten_text1 = Flatten()(embedding_layer1)

    input_text2 = Input(shape=(text_matrix2.shape[1],))
    embedding_layer2 = Embedding(input_dim=len(tokenizer2.word_index) + 1, output_dim=16)(input_text2)
    flatten_text2 = Flatten()(embedding_layer2)

    input_text3 = Input(shape=(text_matrix3.shape[1],))
    embedding_layer3 = Embedding(input_dim=len(tokenizer3.word_index) + 1, output_dim=16)(input_text3)
    flatten_text3 = Flatten()(embedding_layer3)

    input_text4 = Input(shape=(text_matrix4.shape[1],))
    embedding_layer4 = Embedding(input_dim=len(tokenizer4.word_index) + 1, output_dim=16)(input_text4)
    flatten_text4 = Flatten()(embedding_layer4)

    input_numeric_max_scaled = Input(shape=(numeric_max_scaled.shape[1],))
    flatten_numeric_max_scaled = Flatten()(input_numeric_max_scaled)

    numeric_max_scaled_concatenated = concatenate([flatten_text1, flatten_text2, flatten_text3, flatten_text4, flatten_numeric_max_scaled])
    print(numeric_max_scaled_concatenated.shape)

    model = Model(inputs=[input_text1, input_text2, input_text3, input_text4, input_numeric_max_scaled], outputs=numeric_max_scaled_concatenated)
    model.compile(optimizer='adam', loss="mean_squared_error")
    return model

def tokenization(text,x):
    try:
        s3_client.download_file(os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"tokenizer"+str(x)+".pickle", "/tmp/tokenizer"+str(x)+".pickle")
    except:
        return {"message":"not found"}

    with open('/tmp/tokenizer'+str(x)+'.pickle', 'rb') as handle:
        tokenizer = joblib.load(handle)

    sequences=tokenizer.texts_to_sequences(text)
    text_matrix = tokenizer.sequences_to_matrix(sequences, mode='tfidf')

    return text_matrix

def create_tokenizers(text,x):
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(text)
    sequences=tokenizer.texts_to_sequences(text)
    text_matrix = tokenizer.sequences_to_matrix(sequences, mode='tfidf')
    with open('/tmp/tokenizer'+str(x)+'.pickle', 'wb') as handle1:
        joblib.dump(tokenizer, handle1)
    s3_client.upload_file('/tmp/tokenizer'+str(x)+'.pickle', os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"tokenizer"+str(x)+".pickle")
    return text_matrix,tokenizer

def create_input_tensor(text_matrix):
    return tf.convert_to_tensor(text_matrix, dtype=tf.float32)

def get_predictions(record):
    try:
        s3_client.download_file(os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"embedding_model_v2.h5", '/tmp/embedding_model_v2.h5')
    except:
        return {"message":"not found"}

    model = load_model('/tmp/embedding_model_v2.h5')

    text1=pd.DataFrame()
    text1["category"]=record.category
    text2=pd.DataFrame()
    text2["sub_category"]=record.sub_category
    text3=pd.DataFrame()
    text3["city"]=record.city
    text4=pd.DataFrame()
    text4["address"]=record.address

    numeric=record.drop(columns=["category","sub_category","city","address"])
    numeric_max_scaled = numeric.copy()

    for column in numeric_max_scaled.columns:
        numeric_max_scaled[column] = numeric_max_scaled[column]  / numeric_max_scaled[column].abs().max()
        if column == "price":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.8
        elif column == "landSize":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.6
        elif column == "bedRooms":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.5
        elif column == "washRooms":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.4


    numeric=numeric_max_scaled

    text1=text1.values.flatten()
    text2=text2.values.flatten()
    text3=text3.values.flatten()
    text4=text4.values.flatten()

    numeric_max_scaled=numeric_max_scaled.values


    text_matrix1=tokenization(text1,1)
    text_matrix2=tokenization(text2,2)
    text_matrix3=tokenization(text3,3)
    text_matrix4=tokenization(text4,4)


    text_matrix1 = text_matrix1 * 1
    text_matrix2 = text_matrix2 * 0.9
    text_matrix3 = text_matrix3 * 0.7
    text_matrix4 = text_matrix4 * 0.3


    text_matrix_tensor1 = create_input_tensor(text_matrix1)
    text_matrix_tensor2 = create_input_tensor(text_matrix2)
    text_matrix_tensor3 = create_input_tensor(text_matrix3)
    text_matrix_tensor4 = create_input_tensor(text_matrix4)

    numeric_max_scaled_tensor = tf.convert_to_tensor(numeric_max_scaled, dtype=tf.float32)
    print(text_matrix_tensor1.shape, text_matrix_tensor2.shape, text_matrix_tensor3.shape, text_matrix_tensor4.shape, numeric_max_scaled_tensor.shape)
    prediction=model.predict([ text_matrix_tensor1, text_matrix_tensor2, text_matrix_tensor3, text_matrix_tensor4, numeric_max_scaled_tensor])

    return prediction

#=====================================================================================API STRATS HERE
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def decode_jwt_token(token, secret_key):
    try:
        decoded_token = jwt.decode(token, secret_key, algorithms=["HS256"])
        return decoded_token
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_user(token: str = Depends(oauth2_scheme)):
    decoded = decode_jwt_token(token, os.environ['JWT_SECRET'])
    return decoded


#=====================================================================================Give Recommendations (Content based)
@app.get('/recommendations_listing', response_model=Page[Inventory])
async def get_recommendation(pg : int , sz : int, city : Optional[str]="All Cities" , Auth: dict = Depends(get_current_user)):
    print(city)
    pagination_params=Params(page=pg,size=sz)

    print("Welcome ",Auth['email'])
    conn=initiate_dbaccess()
    print("Database connected successfully")

    cur = conn.cursor()
    cur.execute("""SELECT lambda_count."recommendation" FROM lambda_count WHERE lambda_count."id"=1 """)
    row=cur.fetchall()
    c1=row[0][0]+1
    cur = conn.cursor()
    cur.execute("""UPDATE lambda_count SET recommendation = (%s) WHERE lambda_count."id"=1""",(c1,))
    conn.commit()

    UserID=Auth['id']
    print("User ID: " , UserID)

    cur = conn.cursor()

    cur.execute("""SELECT IR."inventoryId",IR."type" FROM inventory_recomendation as IR WHERE
                    IR."userId" = (%s) ORDER BY IR."createdAt" """,(UserID,))

    distinct = cur.fetchall()
    colnames = [desc[0] for desc in cur.description]
    dis = pd.DataFrame(distinct, columns = colnames)
    df_no_duplicates = dis[~dis.duplicated(keep='last')]
    rows = df_no_duplicates.tail(4).values

    listing_ids = []
    hotlisting_ids = []

    df=pd.DataFrame(rows,columns=colnames)
    df["type"]=[typ.lower() for typ in df["type"].values]
    df1=df.groupby('type')['inventoryId'].apply(list).reset_index(name="inventories")

    row1,row2 = [],[]

    if "listing" in df1["type"].values:
        listing_ids=df1[df1["type"]=="listing"]['inventories'].values[0]

        cur = conn.cursor()
        cur.execute("""
            SELECT listing_invs.*, LA."title" as land_title FROM land_area as LA JOIN
            (SELECT inv_list.*, pro."city", pro."address" FROM project as pro JOIN
            (SELECT invents.*, list."saleCommission" FROM listing as list JOIN
            (SELECT invent.*, pst."title" as sub_category FROM project_sub_type as pst JOIN
            (SELECT inv."id", inv."projectSubTypeId", inv."projectId", inv."landAreaId",
            inv."price", inv."washRooms", inv."bedRooms", inv."landSize",
            pt."title" as category FROM inventory as inv JOIN
            project_type as pt ON inv."projectTypeId"=pt."id") as invent
            ON pst."id"=invent."projectSubTypeId") as invents
            ON list."inventoryId"=invents."id" WHERE list."status"=(%s)
            AND list."deletedAt" IS NULL) as inv_list
            ON inv_list."projectId"=pro."id") as listing_invs
            ON listing_invs."landAreaId"=LA."id" AND listing_invs."id" IN %s
            """, ('Approved', tuple(listing_ids)))
        row1 = cur.fetchall()

    if "hotlisting" in df1["type"].values:
        hotlisting_ids=df1[df1["type"]=="hotlisting"]['inventories'].values[0]
        cur = conn.cursor()
        cur.execute("""
            SELECT listing_invs.*, LA."title" as land_title FROM land_area as LA JOIN
            (SELECT inv_list.*, pro."city", pro."address" FROM project as pro JOIN
            (SELECT invents.*, hotlist."saleCommission" FROM hot_listing as hotlist JOIN
            (SELECT invent.*, pst."title" as sub_category FROM project_sub_type as pst JOIN
            (SELECT inv."id", inv."projectSubTypeId", inv."projectId", inv."landAreaId",
            inv."price", inv."washRooms", inv."bedRooms", inv."landSize",
            pt."title" as category FROM inventory as inv JOIN
            project_type as pt ON inv."projectTypeId"=pt."id") as invent
            ON pst."id"=invent."projectSubTypeId") as invents
            ON hotlist."inventoryId"=invents."id" WHERE hotlist."status"=(%s)
            AND hotlist."deletedAt" IS NULL) as inv_list
            ON inv_list."projectId"=pro."id") as listing_invs
            ON listing_invs."landAreaId"=LA."id" AND listing_invs."id" IN %s
            """, ('Approved', tuple(hotlisting_ids)))
        row2 = cur.fetchall()

    print("listing_ids: ", listing_ids)
    print("hotlisting_ids: ", hotlisting_ids)

    colnames = [desc[0] for desc in cur.description]
    row=row1+row2
    data = pd.DataFrame(row , columns = colnames)

    if row!=[]:
        colnames = [desc[0] for desc in cur.description]
        agency_inventory = pd.DataFrame(row, columns = colnames)
        agency_inventory=agency_inventory.fillna(0)
        if 0 in agency_inventory['category'].values: agency_inventory['category'].replace(0,'',inplace=True)
        if 0 in agency_inventory['sub_category'].values: agency_inventory['sub_category'].replace(0,'',inplace=True)
        if 0 in agency_inventory['city'].values: agency_inventory['city'].replace(0,'',inplace=True)
        if 0 in agency_inventory['address'].values: agency_inventory['address'].replace(0,'',inplace=True)
        if 0 in agency_inventory['land_title'].values: agency_inventory['land_title'].replace(0,'',inplace=True)

        agency_inventory['landSize']=agency_inventory['landSize'].astype("float64")

        if "Square Yards" in agency_inventory['land_title'].values:
            agency_inventory.loc[agency_inventory['land_title']=="Square Yards","landSize"]*=9
        if "Square Meters" in agency_inventory['land_title'].values:
            agency_inventory.loc[agency_inventory['land_title']=="Square Meters","landSize"]*=10.764
        if "Marla" in agency_inventory['land_title'].values:
            agency_inventory.loc[agency_inventory['land_title']=="Marla","landSize"]*=272.3
        if "Kanal" in agency_inventory['land_title'].values:
            agency_inventory.loc[agency_inventory['land_title']=="Kanal","landSize"]*=5445


        agency_inventory.loc[:,"land_title"]="Square Feet"

        agency_inventory = agency_inventory.drop(columns=['projectSubTypeId','landAreaId','land_title'])

    else:
        return paginate([],pagination_params)

    final_result = agency_inventory

    getpreds=get_predictions(final_result)
    data_array = np.array(getpreds)
    preds = np.mean(data_array, axis=0 , keepdims=True)

    for i in range(0,len(preds[0])):
        if math.isnan(preds[0][i])==True:
            preds[0][i]=0

    try:
        s3_client.download_file(os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"ds_preds1.npy", '/tmp/ds_preds1.npy')
    except:
        return paginate([],pagination_params)

    ds_preds = load('/tmp/ds_preds1.npy')

    similarities = cosine_similarity(preds, ds_preds)

    cur = conn.cursor()
    cur.execute("""
        SELECT listing_inventories.*, photos.photo FROM project_photos as photos RIGHT JOIN
        (SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
        (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
        (SELECT invents.*,list."saleCommission",list."agencyId" FROM listing as list JOIN
        (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
        (SELECT inv."id",inv."title",inv."description",inv."price",inv."projectSubTypeId",inv."projectId",inv."landSize",inv."landAreaId",inv."noOfUnit",inv."noOfSold",inv."inVentoryType",pt."title"
            as category FROM inventory as inv JOIN project_type as pt ON inv."projectTypeId"=pt."id") as invent
        ON pst."id"=invent."projectSubTypeId") as invents
        ON list."inventoryId"=invents."id" WHERE list."status"=(%s) and list."deletedAt" IS NULL) as inv_list
        ON inv_list."projectId"=pro."id") as listing_invs
        ON listing_invs."landAreaId"=LA."id") as listing_inventories
        ON listing_inventories."projectId"=photos."projectId"
        """,("Approved",))


    rows1 = cur.fetchall()
    listing=["list" for i in range(len(rows1))]

    cur = conn.cursor()
    cur.execute("""
        SELECT listing_inventories.*, photos.photo FROM project_photos as photos RIGHT JOIN
        (SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
        (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
        (SELECT invents.*,hotlist."saleCommission",hotlist."agencyId" FROM hot_listing as hotlist JOIN
        (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
        (SELECT inv."id",inv."title",inv."description",inv."price",inv."projectSubTypeId",inv."projectId",inv."landSize",inv."landAreaId",inv."noOfUnit",inv."noOfSold",inv."inVentoryType",pt."title"
            as category FROM inventory as inv JOIN project_type as pt ON inv."projectTypeId"=pt."id") as invent
        ON pst."id"=invent."projectSubTypeId") as invents
        ON hotlist."inventoryId"=invents."id" WHERE hotlist."status"=(%s) and hotlist."deletedAt" IS NULL) as inv_list
        ON inv_list."projectId"=pro."id") as listing_invs
        ON listing_invs."landAreaId"=LA."id") as listing_inventories
        ON listing_inventories."projectId"=photos."projectId"
        """,("Approved",))

    colnames = [desc[0] for desc in cur.description]
    rows2 = cur.fetchall()
    hotlist=["hot" for i in range(len(rows2))]

    rows=rows1+rows2

    if rows==[]:
        conn.close()
        print("Database connection closed")
        return paginate([],pagination_params)

    type=listing+hotlist

    inventories=pd.DataFrame(rows,columns=colnames)
    inventories['type']=type
    col=colnames[0:18]
    col.append("type")
    inventories.fillna("xyz",inplace=True)
    inventories=inventories.groupby(col,sort = False)["photo"].apply(list).reset_index(name="photos")
    inventories["similarity"]=similarities[0]
    inventory_ids=inventories['id']
    inventory_agency_ids=inventories['agencyId']
    inventory_ids=inventory_ids.values
    inventory_agency_ids=inventory_agency_ids.values

    cur = conn.cursor()
    cur.execute("""
        SELECT pro."agencyId" FROM profile as pro WHERE pro."userId"=(%s)
        """,(UserID,))

    row = cur.fetchall()
    myagency=row[0][0]

    conn.close()
    print("Database connection closed")

    inventories.sort_values(by=["similarity"],ascending=False,inplace=True)
    inventories=inventories[(inventories.noOfUnit!=inventories.noOfSold) & (inventories.agencyId!=myagency)]

    if city!="All Cities":
        inventories=inventories[(inventories["city"]==city.capitalize()) | (inventories["city"]==city.lower())]

    print(inventories["id"].values)
    print(inventories["similarity"].values)

    ret=inventories

    result = ret.to_json(orient="records")
    parsed = loads(result)
    return paginate(parsed, pagination_params)

#=====================================================================================Update Listings Embeddings
@app.post('/update_ds_embeddings_listing')
async def create_ds_embeddings():

    conn=initiate_dbaccess()

    cur = conn.cursor()
    cur.execute("""SELECT lambda_count."recommendation_update" FROM lambda_count WHERE lambda_count."id"=1 """)
    row=cur.fetchall()
    print(row[0][0])
    c1=row[0][0]+1
    cur = conn.cursor()
    cur.execute("""UPDATE lambda_count SET recommendation_update = (%s) WHERE lambda_count."id"=1 """,(c1,))
    conn.commit()

    cur = conn.cursor()
    cur.execute("""
        SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
        (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
        (SELECT invents.*,list."saleCommission" FROM listing as list JOIN
        (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
        (SELECT inv."id",inv."projectSubTypeId",inv."projectId",inv."landAreaId",inv."price",inv."washRooms",inv."bedRooms",inv."landSize",pt."title" as category FROM inventory as inv JOIN project_type as pt ON inv."projectTypeId"=pt."id") as invent
        ON pst."id"=invent."projectSubTypeId") as invents
        ON list."inventoryId"=invents."id" WHERE list."status"=(%s) and list."deletedAt" IS NULL) as inv_list
        ON inv_list."projectId"=pro."id") as listing_invs
        ON listing_invs."landAreaId"=LA."id"
        """,("Approved",))

    colnames = [desc[0] for desc in cur.description]
    rows1 = cur.fetchall()

    cur.execute("""
        SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
        (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
        (SELECT invents.*,hotlist."saleCommission" FROM hot_listing as hotlist JOIN
        (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
        (SELECT inv."id",inv."projectSubTypeId",inv."projectId",inv."landAreaId",inv."price",inv."washRooms",inv."bedRooms",inv."landSize",pt."title" as category FROM inventory as inv JOIN project_type as pt ON inv."projectTypeId"=pt."id") as invent
        ON pst."id"=invent."projectSubTypeId") as invents
        ON hotlist."inventoryId"=invents."id" WHERE hotlist."status"=(%s) and hotlist."deletedAt" IS NULL) as inv_list
        ON inv_list."projectId"=pro."id") as listing_invs
        ON listing_invs."landAreaId"=LA."id"
        """,("Approved",))

    rows2 = cur.fetchall()
    rows=rows1+rows2

    if rows==[]:
        return {"message":"not found"}

    print(np.array(rows1).shape,np.array(rows2).shape,np.array(rows).shape)
    agency_inventories=pd.DataFrame(rows,columns=colnames)
    agency_inventories.sort_values(by = 'id' , ascending=True , inplace=True)
    print(agency_inventories.count())
    agency_inventories['landSize']=agency_inventories['landSize'].astype("float64")

    if "Square Yards" in agency_inventories['land_title'].values:
        agency_inventories.loc[agency_inventories['land_title']=="Square Yards","landSize"]*=9
    if "Square Meters" in agency_inventories['land_title'].values:
        agency_inventories.loc[agency_inventories['land_title']=="Square Meters","landSize"]*=10.764
    if "Marla" in agency_inventories['land_title'].values:
        agency_inventories.loc[agency_inventories['land_title']=="Marla","landSize"]*=272.3
    if "Kanal" in agency_inventories['land_title'].values:
        agency_inventories.loc[agency_inventories['land_title']=="Kanal","landSize"]*=5445


    agency_inventories.loc[:,"land_title"]="Square Feet"

    agency_inventories.drop(columns=["projectSubTypeId","landAreaId","land_title"], inplace=True)

    text1=pd.DataFrame()
    text1["category"]=agency_inventories.category
    text2=pd.DataFrame()
    text2["sub_category"]=agency_inventories.sub_category
    text3=pd.DataFrame()
    text3["city"]=agency_inventories.city
    text4=pd.DataFrame()
    text4["address"]=agency_inventories.address

    numeric_max_scaled=agency_inventories.drop(columns=["category","sub_category","city","address"])
    for column in numeric_max_scaled.columns:
        numeric_max_scaled[column] = numeric_max_scaled[column]  / numeric_max_scaled[column].abs().max()
        if column == "price":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.8
        elif column == "landSize":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.6
        elif column == "bedRooms":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.5
        elif column == "washRooms":
            numeric_max_scaled[column] = numeric_max_scaled[column] * 0.4


    text1=text1.fillna("")
    text2=text2.fillna("")
    text3=text3.fillna("")
    text4=text4.fillna("")
    numeric_max_scaled=numeric_max_scaled.fillna(0)

    text1=text1.values.flatten()
    text2=text2.values.flatten()
    text3=text3.values.flatten()
    text4=text4.values.flatten()
    numeric_max_scaled=numeric_max_scaled.values

    text_matrix1,tokenizer1=create_tokenizers(text1,1)
    text_matrix2,tokenizer2=create_tokenizers(text2,2)
    text_matrix3,tokenizer3=create_tokenizers(text3,3)
    text_matrix4,tokenizer4=create_tokenizers(text4,4)

    text_matrix1 = text_matrix1 * 1
    text_matrix2 = text_matrix2 * 0.9
    text_matrix3 = text_matrix3 * 0.7
    text_matrix4 = text_matrix4 * 0.3

    text_matrix_tensor1 = tf.convert_to_tensor(text_matrix1, dtype=tf.float32)
    text_matrix_tensor2 = tf.convert_to_tensor(text_matrix2, dtype=tf.float32)
    text_matrix_tensor3 = tf.convert_to_tensor(text_matrix3, dtype=tf.float32)
    text_matrix_tensor4 = tf.convert_to_tensor(text_matrix4, dtype=tf.float32)

    print(numeric_max_scaled.shape,text_matrix1.shape,text_matrix2.shape,text_matrix3.shape,text_matrix4.shape)
    numeric_max_scaled_tensor = tf.convert_to_tensor(numeric_max_scaled, dtype=tf.float32)

    model=get_model(text_matrix1,text_matrix2,text_matrix3,text_matrix4,numeric_max_scaled,tokenizer1,tokenizer2,tokenizer3,tokenizer4)
    model.save('/tmp/embedding_model_v2.h5')
    s3_client.upload_file('/tmp/embedding_model_v2.h5', os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"embedding_model_v2.h5")

    predictions=model.predict([text_matrix_tensor1, text_matrix_tensor2, text_matrix_tensor3, text_matrix_tensor4, numeric_max_scaled_tensor])
    print(predictions)
    save('/tmp/ds_preds1.npy', predictions)
    s3_client.upload_file('/tmp/ds_preds1.npy', os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"ds_preds1.npy")
    conn.close()
    return {"message":"updated"}


if __name__ == '__main__':
    add_pagination(app)
    uvicorn.run(app, host="0.0.0.0", port=3000)
