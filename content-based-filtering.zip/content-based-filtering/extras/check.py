import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from fastapi.logger import logger
from fastapi.security import OAuth2PasswordBearer
import numpy as np
import pandas as pd
import os
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, concatenate, Flatten
from tensorflow.keras.models import load_model
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv
import psycopg2
from numpy import save
from numpy import load
# import pickle5 as pickle
from json import loads, dumps
import jwt
import boto3
from sklearn.cluster import KMeans
import joblib
import math


def initiate_dbaccess():
    DB_NAME = "property_wallet_staging"
    DB_USER = "postgres"
    DB_PASS = "Panasonic1"
    DB_HOST = "karachihills.cquxw3hgishy.ap-south-1.rds.amazonaws.com"
    DB_PORT = 5432

    conn = psycopg2.connect(
        database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)

    return conn


# print("Welcome ",Auth['email'])
conn=initiate_dbaccess()
print("Database connected successfully")

# result_dataframes = []

UserID = 503
print(UserID)

# Fetching distinct recommendations
cur = conn.cursor()
cur.execute("""SELECT IR."inventoryId", IR."type" FROM inventory_recomendation as IR WHERE
                IR."userId" = (%s) ORDER BY IR."createdAt" """, (UserID,))

distinct = cur.fetchall()
colnames = [desc[0] for desc in cur.description]
dis = pd.DataFrame(distinct, columns=colnames)
df_no_duplicates = dis[~dis.duplicated(keep='last')]
rows = df_no_duplicates.tail(4).values
print("rows :")
print(rows)

listing_ids = []
hotlisting_ids = []

df=pd.DataFrame(rows,columns=colnames)
df["type"]=[typ.lower() for typ in df["type"].values]
df1=df.groupby('type')['inventoryId'].apply(list).reset_index(name="inventories")
print(df1.head())

listing_ids=df1[df1["type"]=="listing"]['inventories'].values[0]
hotlisting_ids=df1[df1["type"]=="hotlisting"]['inventories'].values[0]

print("listing_ids: ", listing_ids)
print("hotlisting_ids: ", hotlisting_ids)


cur = conn.cursor()
cur.execute("""
    SELECT listing_invs.*, LA."title" as land_title FROM land_area as LA JOIN
    (SELECT inv_list.*, pro."city", pro."address" FROM project as pro JOIN
    (SELECT invents.*, list."saleCommission" FROM listing as list JOIN
    (SELECT invent.*, pst."title" as sub_category FROM project_sub_type as pst JOIN
    (SELECT inv."id", inv."projectSubTypeId", inv."projectId", inv."landAreaId",
    inv."price", inv."washRooms", inv."bedRooms", inv."landSize",
    pt."title" as category FROM inventory as inv JOIN
    project_type as pt ON inv."projectTypeId"=pt."id") as invent
    ON pst."id"=invent."projectSubTypeId") as invents
    ON list."inventoryId"=invents."id" WHERE list."status"=(%s)
    AND list."deletedAt" IS NULL) as inv_list
    ON inv_list."projectId"=pro."id") as listing_invs
    ON listing_invs."landAreaId"=LA."id" AND listing_invs."id" IN %s
    """, ('Approved', tuple(listing_ids)))
row1 = cur.fetchall()

# colnames = [desc[0] for desc in cur.description]
# listing_inventory = pd.DataFrame(row1, columns=colnames)
# result_dataframes.append(listing_inventory)

cur = conn.cursor()
cur.execute("""
    SELECT listing_invs.*, LA."title" as land_title FROM land_area as LA JOIN
    (SELECT inv_list.*, pro."city", pro."address" FROM project as pro JOIN
    (SELECT invents.*, hotlist."saleCommission" FROM hot_listing as hotlist JOIN
    (SELECT invent.*, pst."title" as sub_category FROM project_sub_type as pst JOIN
    (SELECT inv."id", inv."projectSubTypeId", inv."projectId", inv."landAreaId",
    inv."price", inv."washRooms", inv."bedRooms", inv."landSize",
    pt."title" as category FROM inventory as inv JOIN
    project_type as pt ON inv."projectTypeId"=pt."id") as invent
    ON pst."id"=invent."projectSubTypeId") as invents
    ON hotlist."inventoryId"=invents."id" WHERE hotlist."status"=(%s)
    AND hotlist."deletedAt" IS NULL) as inv_list
    ON inv_list."projectId"=pro."id") as listing_invs
    ON listing_invs."landAreaId"=LA."id" AND listing_invs."id" IN %s
    """, ('Approved', tuple(hotlisting_ids)))
row2 = cur.fetchall()
print("Row",row2)


colnames = [desc[0] for desc in cur.description]
row=row1+row2
result_dataframes = pd.DataFrame(row, columns=colnames)
# print(hotlisting_inventory)
# result_dataframes.append(hotlisting_inventory)

result_dataframes.head(5)
# # Check if any data is fetched
# if not result_dataframes:
#     print("Database connection closed")
#     result = {"message": "not found"}
# else:
#     final_result = pd.concat(result_dataframes, ignore_index=True)
#     print("final_result ",final_result)
    # result = {"message": "success", "data": final_result.to_dict(orient='records')}

# # Close the connection
# conn.close()
# print("Database connection closed")
# return result



















# UserID=28
# print(UserID)

# cur = conn.cursor()  # creating a cursor

# # cur.execute("""SELECT * FROM inventory_recomendation as recom WHERE recom."userId"=(%s);""",(UserID,))
# # rows=cur.fetchall()

# cur.execute("""SELECT IR."inventoryId",IR."type" FROM inventory_recomendation as IR WHERE
#                 IR."userId" = (%s) ORDER BY IR."createdAt" """,(UserID,))

# distinct = cur.fetchall()
# colnames = [desc[0] for desc in cur.description]
# dis = pd.DataFrame(distinct, columns = colnames)
# df_no_duplicates = dis[~dis.duplicated(keep='last')]
# rows = df_no_duplicates.tail(4).values
# print("rows :")
# print(rows)



# listing_ids = []
# hotlisting_ids = []

# for row in rows:
#     inventory_id, inventory_type = row
#     if inventory_type == 'Listing':
#         listing_ids.append(inventory_id)
#     elif inventory_type == 'hotListing':
#         hotlisting_ids.append(inventory_id)


# print("listing_ids: ",listing_ids)
# print("hotlisting_ids: ",hotlisting_ids)


# cur = conn.cursor()
# cur.execute("""
#     SELECT listing_invs.*, LA."title" as land_title FROM land_area as LA JOIN
#     (SELECT inv_list.*, pro."city", pro."address" FROM project as pro JOIN
#     (SELECT invents.*, list."saleCommission" FROM listing as list JOIN
#     (SELECT invent.*, pst."title" as sub_category FROM project_sub_type as pst JOIN
#     (SELECT inv."id", inv."projectSubTypeId", inv."projectId", inv."landAreaId",
#     inv."price", inv."washRooms", inv."bedRooms", inv."landSize",
#     pt."title" as category FROM inventory as inv JOIN
#     project_type as pt ON inv."projectTypeId"=pt."id") as invent
#     ON pst."id"=invent."projectSubTypeId") as invents
#     ON list."inventoryId"=invents."id" WHERE list."status"=(%s)
#     AND list."deletedAt" IS NULL) as inv_list
#     ON inv_list."projectId"=pro."id") as listing_invs
#     ON listing_invs."landAreaId"=LA."id" AND listing_invs."id" IN %s
#     """, ('Approved', tuple(listing_ids)))
# row = cur.fetchall()
# print("Row After Query : " , row)


# colnames = [desc[0] for desc in cur.description]
# dis = pd.DataFrame(row, columns = colnames)
# print(dis)






# result_dataframes = []
# for rows in row:
#     inv_id = rows[0]
#     print("inventory_id: ",inv_id)
#     listing_type = rows[1]

#     if listing_type is not None:
#         if listing_type=="HoTListing":
#             cur = conn.cursor()
#             cur.execute("""
#                 SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
#                 (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
#                 (SELECT invents.*,hotlist."saleCommission" FROM hot_listing as hotlist JOIN
#                 (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
#                 (SELECT inv."id",inv."projectSubTypeId",inv."projectId",inv."landAreaId",
#                 inv."price",inv."washRooms",inv."bedRooms",inv."landSize",
#                 pt."title" as category FROM inventory as inv JOIN
#                 project_type as pt ON inv."projectTypeId"=pt."id") as invent
#                 ON pst."id"=invent."projectSubTypeId") as invents
#                 ON hotlist."inventoryId"=invents."id" WHERE hotlist."status"=(%s) and hotlist."deletedAt" IS NULL) as inv_list
#                 ON inv_list."projectId"=pro."id") as listing_invs
#                 ON listing_invs."landAreaId"=LA."id" and listing_invs."id"=(%s)
#                 """,('Approved',inv_id,))
#             row = cur.fetchall()

#         if listing_type=="Listing":
#             cur = conn.cursor()
#             cur.execute("""
#                 SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
#                 (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
#                 (SELECT invents.*,list."saleCommission" FROM listing as list JOIN
#                 (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
#                 (SELECT inv."id",inv."projectSubTypeId",inv."projectId",
#                 inv."landAreaId",inv."price",inv."washRooms",inv."bedRooms",
#                 inv."landSize",pt."title" as category FROM inventory as inv JOIN
#                 project_type as pt ON inv."projectTypeId"=pt."id") as invent
#                 ON pst."id"=invent."projectSubTypeId") as invents
#                 ON list."inventoryId"=invents."id" WHERE list."status"=(%s) and list."deletedAt" IS NULL) as inv_list
#                 ON inv_list."projectId"=pro."id") as listing_invs
#                 ON listing_invs."landAreaId"=LA."id" and listing_invs."id"=(%s)
#                 """,('Approved',inv_id,))
#             row = cur.fetchall()


#         if row!=[]:
#             #     conn.close()
#             #     print("Database connection    closed")
#             #     return {"message":"not found"}

#             colnames = [desc[0] for desc in cur.description]

#             agency_inventory = pd.DataFrame(row, columns = colnames)
#             # print(agency_inventory)
#             # agency_inventory = agency_inventory.drop(column="status")
#             # print("==============================================")
#             # print(len(colnames),colnames)
#             agency_inventory=agency_inventory.fillna(0)
#             if 0 in agency_inventory['category'].values: agency_inventory['category'].replace(0,'',inplace=True)
#             if 0 in agency_inventory['sub_category'].values: agency_inventory['sub_category'].replace(0,'',inplace=True)
#             if 0 in agency_inventory['city'].values: agency_inventory['city'].replace(0,'',inplace=True)
#             if 0 in agency_inventory['address'].values: agency_inventory['address'].replace(0,'',inplace=True)
#             if 0 in agency_inventory['land_title'].values: agency_inventory['land_title'].replace(0,'',inplace=True)

#             # agency_inventory=agency_inventory.groupby(colnames[0:14])['photo'].apply(list).reset_index(name='photos')

#             agency_inventory = agency_inventory.drop(columns=['projectSubTypeId','landAreaId'])
#             # agency_inventory=agency_inventory[agency_inventory.deletedAt.isnull()]
#             # colnames.remove('deletedAt')
#             # print(agency_inventory)
#             # agency_inventory = pd.DataFrame(agency_inventory)
#             result_dataframes.append(agency_inventory)
#             # print(agency_inventory.iloc[:4])
#             # print(agency_inventory.head())
#             # print(result_dataframes)

#     else:
#         print ("Listing Type not found")


# # print(result_dataframes)
# if result_dataframes ==[]:
#     print("Database connection closed")

# final_result = pd.concat(result_dataframes, ignore_index=True)
# print(final_result)
