import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File
import cv2
import numpy as np
import fingerprint_enhancer
import os
from fastapi.responses import JSONResponse
import base64
from deepface import DeepFace
import shutil
from mangum import Mangum
# import tempfile

app = FastAPI()
handler = Mangum(app)
@app.get('/health-check')
async def healthCheck():
    return Response(content="hello world")

@app.post('/face_verification')
async def post_basic_form(request: Request, face1: UploadFile = File(...), face2: UploadFile = File(...)):

    models = ["VGG-Face", "Facenet", "Facenet512", "OpenFace", "DeepFace", "DeepID", "ArcFace", "Dlib", "SFace"]
    content = await face1.read()
    image = np.asarray(bytearray(content), dtype="uint8")
    image = cv2.imdecode(image, cv2.IMREAD_COLOR)
    cv2.imwrite("/tmp/face1.jpeg", image)
    content1 = await face2.read()
    image1 = np.asarray(bytearray(content1), dtype="uint8")
    image1 = cv2.imdecode(image1, cv2.IMREAD_COLOR)
    cv2.imwrite("/tmp/face2.jpeg", image1)
    result = DeepFace.verify(img1_path ="/tmp/face1.jpeg", img2_path ="/tmp/face2.jpeg", model_name=models[2], enforce_detection=False)
    print(result)
    if result['verified']:
        return {"status" : 'verified'}
    else:
        return {"status" : 'not-verified'}


if __name__ == '__main__':
    uvicorn.run(app)
    # uvicorn.run(app,host="0.0.0.0", port=9000)
