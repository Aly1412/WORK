import spacy
from spacy.tokens import DocBin
from tqdm import tqdm
import json
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
import joblib
import uvicorn
import pandas as pd
# from mangum import Mangum

app=FastAPI()

# handler = Mangum(app)

navdata=pd.read_csv("navdata.csv")

nlp = spacy.load('output/model-best')


input_enc=joblib.load("input_encoder.pkl")
output_enc=joblib.load("output_encoder.pkl")
dt=joblib.load("DTree.pkl")

@app.get("/health-check")
def health_check():
  return 'Hello World'

@app.get("/voice_navigation")
def navigation(command:str):
  doc = nlp(command)
  response={} 
  for ent in doc.ents:
    response[ent.label_]=ent.text
  # print(ent.text, "  ->>>>  ", ent.label_)
  print(command)
  print(response)


  if ("SCREEN" in response.keys()) and (str.lower(response["SCREEN"]) in navdata["Screen"].values):
    response["SCREEN"]=str.lower(response["SCREEN"])
    if ("ACTION" in response.keys()) and (str.lower(response["ACTION"]) in navdata["Action"].values):
      response["ACTION"]=str.lower(response["ACTION"])
      predicted = dt.predict(input_enc.transform([(response['ACTION'], response['SCREEN'])]))
      predicted_label = output_enc.inverse_transform([predicted])
      print(predicted_label)

    else:
      predicted = dt.predict(input_enc.transform([("None", response['SCREEN'])]))
      predicted_label = output_enc.inverse_transform([predicted])
      print(predicted_label)

  else:
    return {
    "route": None
    }

  return {
    "route": predicted_label[0][0]
  }

if __name__ == '__main__':
  uvicorn.run(app,host="0.0.0.0",port=3000)
