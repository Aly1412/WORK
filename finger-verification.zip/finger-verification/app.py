import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File
import cv2
import numpy as np
from pydantic import BaseModel
import tensorflow as tf
from tensorflow.keras.applications.vgg16 import VGG16
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import load_model
from mangum import Mangum
from PIL import Image
from pathlib import Path

app = FastAPI()
handler = Mangum(app)

@app.get('/health-check')
async def healthCheck():
    return Response(content="hello world")

@app.post('/match')
async def match(CNIC : str, fing1 : UploadFile = File(...), fing2 : UploadFile = File(...)):
    print(CNIC)

    content = await fing1.read()
    image1 = np.asarray(bytearray(content), dtype="uint8")
    image1 = cv2.imdecode(image1, cv2.IMREAD_COLOR)
    cv2.imwrite("/tmp/"+CNIC+"_fing1.jpg", image1)

    content = await fing2.read()
    image2 = np.asarray(bytearray(content), dtype="uint8")
    image2 = cv2.imdecode(image2, cv2.IMREAD_COLOR)
    cv2.imwrite("/tmp/"+CNIC+"_fing2.jpg", image2)

    file = Path("vgg16.h5")
    if file.exists():
        base_model = load_model('vgg16.h5')
    else:
        base_model = VGG16(weights='imagenet', include_top=False, input_shape=(361, 504, 3))
        base_model.save("vgg16.h5")

    model = tf.keras.Model(inputs=base_model.input, outputs=base_model.output)

    img1 = load_img("/tmp/"+CNIC+"_fing1.jpg", target_size=(361, 504))
    img1 = img_to_array(img1)
    img1 = np.expand_dims(img1, axis=0)
    img1 = preprocess_input(img1)
    feature1 = model.predict(img1)
    feature1 = feature1.flatten()

    img2 = load_img("/tmp/"+CNIC+"_fing2.jpg", target_size=(361, 504))
    img2 = img_to_array(img2)
    img2 = np.expand_dims(img2, axis=0)
    img2 = preprocess_input(img2)
    feature2 = model.predict(img2)
    feature2 = feature2.flatten()

    similarity_score = np.dot(feature1, feature2) / (np.linalg.norm(feature1) * np.linalg.norm(feature2))
    print(similarity_score)

    if similarity_score>0.7:
        return {"user":CNIC, "status":"verified", "match_score":str(similarity_score)}
    else:
        return {"user":CNIC, "status":"not verified", "match_score":str(similarity_score)}

if __name__ == '__main__':
    uvicorn.run(app)
    # uvicorn.run(app,host="0.0.0.0",port=8000)
