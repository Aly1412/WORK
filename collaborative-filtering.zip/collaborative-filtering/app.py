import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from fastapi.logger import logger
from fastapi.security import OAuth2PasswordBearer
import numpy as np
import pandas as pd
import os
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, concatenate, Flatten
from tensorflow.keras.models import load_model
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv
import psycopg2
from numpy import save
from numpy import load
from json import loads, dumps
import jwt
import boto3
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score
import joblib
from pydantic import BaseModel
from fastapi_pagination import Page,paginate,add_pagination,Params
from fastapi_pagination.utils import disable_installed_extensions_check

disable_installed_extensions_check()

# from mangum import Mangum

load_dotenv()

session = boto3.Session(aws_access_key_id=os.environ["aws_access_key_id"], aws_secret_access_key=os.environ["aws_secret_access_key"])
s3 = session.resource('s3')
s3_client = session.client('s3')


app = FastAPI(
    # docs_url=None,
    # redoc_url=None,
)
# handler = Mangum(app)

class Inventory(BaseModel):
    id: int
    title: str
    description: str
    price: np.double
    projectSubTypeId: int
    projectId: int
    landSize: int
    landAreaId: int
    noOfUnit: int
    noOfSold: int
    inVentoryType: str
    category: str
    sub_category: str
    saleCommission: int
    agencyId: int
    city: str
    address: str
    land_title: str
    type: str
    photos: list[str]

@app.get('/health-check')
async def healthCheck():
    return Response(content="hello world")

def initiate_dbaccess():
    DB_NAME = os.environ["DB_NAME"]
    DB_USER = os.environ["DB_USER"]
    DB_PASS = os.environ["DB_PASS"]
    DB_HOST = os.environ["DB_HOST"]
    DB_PORT = os.environ["DB_PORT"]

    conn = psycopg2.connect(database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)

    return conn

#=====================================================================================API STRATS HERE
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def decode_jwt_token(token, secret_key):
    try:
        decoded_token = jwt.decode(token, secret_key, algorithms=["HS256"])
        return decoded_token
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_user(token: str = Depends(oauth2_scheme)):
    decoded = decode_jwt_token(token, os.environ['JWT_SECRET'])
    return decoded


#=====================================================================================Give Recommendations (Collaborative)
@app.get('/people_also_viewed_it', response_model = Page[Inventory])
async def get_people_also_viewed(Inv_Id : int, pg : int, sz : int, Auth: dict = Depends(get_current_user)):

    pagination_params=Params(page=pg,size=sz)

    UserID=Auth['id']
    print("User Id: ",UserID)

    print("Welcome ",Auth['email'])
    conn=initiate_dbaccess()
    print("Database connected successfully")

    cur = conn.cursor()
    cur.execute("""SELECT lambda_count."people_also_viewd" FROM lambda_count WHERE lambda_count."id"=1 """)
    row=cur.fetchall()
    c1=row[0][0]+1
    cur = conn.cursor()
    cur.execute("""UPDATE lambda_count SET people_also_viewd = (%s) WHERE lambda_count."id"=1 """,(c1,))
    conn.commit()

    cur = conn.cursor()

    cur.execute("""SELECT DISTINCT IR."userId",IR."inventoryId" FROM inventory_recomendation as IR WHERE IR."userId"=(%s)""",(UserID,))
    rows=cur.fetchall()
    if rows==[]:
        conn.close()
        print("Database connection closed")
        return paginate([], pagination_params)

    cur = conn.cursor()
    cur.execute("""SELECT DISTINCT IR."userId",IR."inventoryId" FROM inventory_recomendation as IR""")
    rows=cur.fetchall()
    if rows==[]:
        conn.close()
        print("Database connection closed")
        return paginate([], pagination_params)


    colnames=[desc[0] for desc in cur.description]
    newcol=[1 for i in range(len(rows))]
    df=pd.DataFrame(rows,columns=colnames)
    df["newcol"]=newcol

    table = pd.pivot_table(df,index=df.userId,columns=df.inventoryId,values='newcol')
    table.fillna(0,inplace=True)

    UID=UserID

    try:
        s3_client.download_file(os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"cluster_model.pkl", '/tmp/cluster_model.pkl')
    except:
        return {"error":"error occurred while downloading model"}

    clustering_model=joblib.load("/tmp/cluster_model.pkl")
    groups=clustering_model.fit_predict(table.values)

    new_groups=pd.DataFrame()
    users=df.userId.unique()
    new_groups["userIds"]=users
    new_groups["groupIds"]=groups
    groupid=new_groups[new_groups.userIds==UID]['groupIds']

    grouping=new_groups.groupby('groupIds')['userIds'].apply(tuple).reset_index(name="users")
    print(grouping)
    similar_users=grouping[grouping.groupIds==groupid.values[0]]
    sim_users=similar_users.users.values[0]


    cur = conn.cursor()
    cur.execute("""SELECT IR."inventoryId" FROM inventory_recomendation as IR WHERE IR."userId" IN %s""",(sim_users,))
    rows=cur.fetchall()
    if rows==[]:
        conn.close()
        print("Database connection closed")
        return paginate([], pagination_params)

    invens=pd.DataFrame(rows,columns=["inv_id"])
    invens["count"]=[1 for i in rows]
    invens=invens.groupby("inv_id").count().reset_index(False)
    rows=invens["inv_id"]

    rows=np.reshape(rows,(len(rows)))
    rows=[int(dt) for dt in rows]
    print("Inventories: ",rows)

    rows=tuple(rows)
    cur = conn.cursor()

    cur.execute("""
        SELECT listing_inventories.*, photos.photo FROM project_photos as photos JOIN
        (SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
        (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
        (SELECT invents.*,list."saleCommission",list."agencyId" FROM listing as list JOIN
        (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
        (SELECT inv."id",inv."title",inv."description",inv."price",inv."projectSubTypeId",inv."projectId",inv."landSize",inv."landAreaId",inv."noOfUnit",inv."noOfSold",inv."inVentoryType",pt."title"
            as category FROM inventory as inv JOIN project_type as pt ON inv."projectTypeId"=pt."id" WHERE inv."id" IN %s) as invent
        ON pst."id"=invent."projectSubTypeId") as invents
        ON list."inventoryId"=invents."id" WHERE list."status"=(%s) and list."deletedAt" IS NULL) as inv_list
        ON inv_list."projectId"=pro."id") as listing_invs
        ON listing_invs."landAreaId"=LA."id") as listing_inventories
        ON listing_inventories."projectId"=photos."projectId"
        """,(rows,"Approved",))


    rows1 = cur.fetchall()
    listing=["list" for i in range(len(rows1))]

    cur = conn.cursor()

    cur.execute("""
        SELECT listing_inventories.*, photos.photo FROM project_photos as photos JOIN
        (SELECT listing_invs.*,LA."title" as land_title FROM land_area as LA JOIN
        (SELECT inv_list.*,pro."city",pro."address" FROM project as pro JOIN
        (SELECT invents.*,hotlist."saleCommission",hotlist."agencyId" FROM hot_listing as hotlist JOIN
        (SELECT invent.*,pst."title" as sub_category FROM project_sub_type as pst JOIN
        (SELECT inv."id",inv."title",inv."description",inv."price",inv."projectSubTypeId",inv."projectId",inv."landSize",inv."landAreaId",inv."noOfUnit",inv."noOfSold",inv."inVentoryType",pt."title"
            as category FROM inventory as inv JOIN project_type as pt ON inv."projectTypeId"=pt."id" WHERE inv."id" IN %s) as invent
        ON pst."id"=invent."projectSubTypeId") as invents
        ON hotlist."inventoryId"=invents."id" WHERE hotlist."status"=(%s) and hotlist."deletedAt" IS NULL) as inv_list
        ON inv_list."projectId"=pro."id") as listing_invs
        ON listing_invs."landAreaId"=LA."id") as listing_inventories
        ON listing_inventories."projectId"=photos."projectId"
        """,(rows,"Approved",))

    colnames = [desc[0] for desc in cur.description]

    rows2 = cur.fetchall()
    hotlist=["hot" for i in range(len(rows2))]

    rows=rows1+rows2

    if rows==[]:
        conn.close()
        print("Database connection closed")
        return paginate([], pagination_params)

    type=listing+hotlist


    inventories=pd.DataFrame(rows,columns=colnames)
    inventories['type']=type
    col=colnames[0:18]
    col.append("type")
    inventories=inventories.groupby(col)["photo"].apply(list).reset_index(name="photos")
    inventories["count"]=invens["count"]
    inventory_ids=inventories['id']
    inventory_agency_ids=inventories['agencyId']
    inventory_ids=inventory_ids.values
    inventory_agency_ids=inventory_agency_ids.values

    cur = conn.cursor()

    cur.execute("""
        SELECT pro."agencyId" FROM profile as pro WHERE pro."userId"=(%s)
        """,(UserID,))

    row = cur.fetchall()
    myagency=row[0][0]
    conn.close()
    print("Database connection closed")

    inventories.sort_values(by=["count"],ascending=False,inplace=True)
    inventories=inventories[(inventories.id != Inv_Id) & (inventories.noOfUnit!=inventories.noOfSold) & (inventories.agencyId!=myagency)]

    print(inventories["id"].values)
    print(inventories["count"].values)

    ret=inventories

    result = ret.to_json(orient="records")
    parsed = loads(result)
    return paginate(parsed, pagination_params)


@app.post("/user_grouping")
def determine_clusters():
    conn=initiate_dbaccess()
    print("Database connected successfully")

    cur = conn.cursor()
    cur.execute("""SELECT DISTINCT IR."userId",IR."inventoryId" FROM inventory_recomendation as IR""")
    rows=cur.fetchall()
    if rows==[]:
        conn.close()
        print("Database connection closed")
        return {"message":"not found"}


    colnames=[desc[0] for desc in cur.description]
    newcol=[1 for i in range(len(rows))]
    df=pd.DataFrame(rows,columns=colnames)
    df["newcol"]=newcol

    table = pd.pivot_table(df,index=df.userId,columns=df.inventoryId,values='newcol')
    table.fillna(0,inplace=True)

    if len(table.values)<3:
        model = AgglomerativeClustering(n_clusters=1)
        model.fit(table.values)
        optimal_num_clusters = 1
        print("optimal number clusters:", optimal_num_clusters)
    else:
        silhouette_scores = []
        for i in range(3,len(table.values)):
            clusterer = AgglomerativeClustering(n_clusters=i, metric='euclidean', linkage='ward')
            labels = clusterer.fit_predict(table.values)
            silhouette_scores.append(silhouette_score(table.values, labels))

        optimal_num_clusters = silhouette_scores.index(max(silhouette_scores)) + 3
        print("optimal number clusters:", optimal_num_clusters)

    clustering = AgglomerativeClustering(n_clusters=optimal_num_clusters, metric='euclidean', linkage='ward')
    clustering.fit(table.values)

    with open("/tmp/cluster_model.pkl",'wb') as handle:
        joblib.dump(clustering,handle)

    s3_client.upload_file('/tmp/cluster_model.pkl', os.environ['BUCKET_NAME'], os.environ['S3_EBD_FOLDER']+"cluster_model.pkl")

    return {"message":"updated"}


if __name__ == '__main__':
    add_pagination(app)
    uvicorn.run(app, host="0.0.0.0", port=2000)
