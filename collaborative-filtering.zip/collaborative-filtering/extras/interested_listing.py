import uvicorn
from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from fastapi.logger import logger
from fastapi.security import OAuth2PasswordBearer
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv
import psycopg2
from numpy import save
import json
from numpy import load
# import pickle5 as pickle
from json import loads, dumps
from sklearn.metrics import silhouette_score




app = FastAPI()

def initiate_dbaccess():
    DB_NAME = 'property_wallet_staging'
    DB_USER = 'postgres'
    DB_PASS = 'Panasonic1'
    DB_HOST = 'karachihills.cquxw3hgishy.ap-south-1.rds.amazonaws.com'
    DB_PORT = '5432'

    conn = psycopg2.connect(database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)
    
    return conn

# @app.get('/check')
# async def checking():

#     conn = initiate_dbaccess() 
#     print("Database connected successfully")

#     cur = conn.cursor()
#     cur.execute("""SELECT invlist."createdBy" as UserId,invlist."inventoryId" as Interested,inv."title" as title FROM interested_listing as invlist JOIN inventory as inv ON invlist."inventoryId" = inv."id" """)
#     row=cur.fetchall()
#     colnames = [desc[0] for desc in cur.description]
#     data= pd.DataFrame(row,columns = colnames)
#     print(data)
#     # grouping = data.groupby('userid').apply(lambda x: list(zip(x['interested'], x['title']))).reset_index(name='interest')
#     grouping = data.groupby('userid').agg(interest=('interested', list), titles=('title', list)).reset_index()
     
#     # print(row)
#     print(grouping)
#     result = grouping.to_json(orient="records")
#     parsed = loads(result)
    
#     return {
#             "message":"found",
#             "data":parsed
#         }

@app.get('/check')
async def checking():
# page_num: int = 1,page_size : int = 10 => parameters
    conn = initiate_dbaccess() 
    print("Database connected successfully")

    cur = conn.cursor()
    cur.execute("""
        SELECT
            invlist."createdBy" as UserId,
            invlist."inventoryId" as Interested,
            inv."title" as title
        FROM
            interested_listing as invlist
        JOIN
            inventory as inv ON invlist."inventoryId" = inv."id"
        
    """)
    
    row = cur.fetchall()
    colnames = [desc[0] for desc in cur.description]
    data = pd.DataFrame(row, columns=colnames)

    def custom_aggregation(group):
        interested_list = []
        for _, row in group.iterrows():
            interested_list.append({
                "inventory_id": row['interested'],
                "title": row['title']
            })
        
        return pd.Series({
            'userid': group['userid'].iloc[0],
            'interested': interested_list
        })

    grouping = data.groupby('userid').apply(custom_aggregation).reset_index(drop=True)

    print(grouping)
    
    result = grouping.to_json(orient="records")
    parsed = loads(result)
    
    # start = (page_num - 1) * page_size
    # end = start + page_size
    
    return {
        "message": "found",
        "data": parsed
    }

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=3000)
