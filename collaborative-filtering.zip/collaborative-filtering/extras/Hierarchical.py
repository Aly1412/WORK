from fastapi import FastAPI, Request, Response, Form, Depends, UploadFile, File, HTTPException, status
from fastapi.logger import logger
from fastapi.security import OAuth2PasswordBearer
import numpy as np
import pandas as pd
import os
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, concatenate, Flatten
from tensorflow.keras.models import load_model
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv
import psycopg2
from numpy import save
from numpy import load
# import pickle5 as pickle
from json import loads, dumps
from sklearn.metrics import silhouette_score
import jwt
import boto3
from sklearn.cluster import KMeans
import joblib
import math
# from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram

load_dotenv()


app = FastAPI(
    docs_url=None,
    redoc_url=None,
)
# handler = Mangum(app)

@app.get('/health-check')
async def healthCheck():
    return Response(content="hello world")

def initiate_dbaccess():
    DB_NAME = 'property_wallet'
    DB_USER = 'postgres'
    DB_PASS = 'Panasonic1'
    DB_HOST = 'karachihills.cquxw3hgishy.ap-south-1.rds.amazonaws.com'
    DB_PORT = '5432'

    conn = psycopg2.connect(database=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS,
                            host=DB_HOST,
                            port=DB_PORT)

    return conn


conn = initiate_dbaccess()
print("Database connected successfully")

cur = conn.cursor()
cur.execute("""SELECT lambda_count."people_also_viewd" FROM lambda_count WHERE lambda_count."id"=1 """)
row = cur.fetchall()
print(row[0][0])
c1 = row[0][0] + 1
cur = conn.cursor()
cur.execute("""UPDATE lambda_count SET people_also_viewd = (%s) WHERE lambda_count."id"=1 """, (c1,))
conn.commit()

UserID = 1
print(UserID)

cur = conn.cursor()
cur.execute("""SELECT DISTINCT IR."userId",IR."inventoryId" FROM inventory_recomendation as IR WHERE IR."userId"=(%s)""", (UserID,))
rows = cur.fetchall()
if rows == []:
    conn.close()
    print("Database connection closed")
    # return {"message": "not found"}

cur = conn.cursor()
cur.execute("""SELECT DISTINCT IR."userId",IR."inventoryId" FROM inventory_recomendation as IR""")
rows = cur.fetchall()
if rows == []:
    conn.close()
    print("Database connection closed")
    # return {"message": "not found"}

colnames = [desc[0] for desc in cur.description]
newcol = [1 for i in range(len(rows))]
df = pd.DataFrame(rows, columns=colnames)
df["newcol"] = newcol

print("data" , df)
grouped = df.groupby('userId')["inventoryId"].apply(list).reset_index(name="inventries")
print(grouped)

table = pd.pivot_table(df, index=df.userId, columns=df.inventoryId, values='newcol')
table.fillna(0, inplace=True)
print(table)

# plt.scatter(df.userId, df.inventoryId)
# plt.show()

UID = UserID
u_rec = table[table.index == UID]
print("UID ",UID)
print("U_rec ",u_rec)

silhouette_scores = []
for i in range(3, len(table.values)):
    clusterer = AgglomerativeClustering(n_clusters=i, metric='euclidean', linkage='ward')
    # clusterer = KMeans(n_clusters=i)
    labels = clusterer.fit_predict(table.values)
    silhouette_scores.append(silhouette_score(table.values, labels))

print(silhouette_scores)
# Choose the number of clusters that maximizes the silhouette score
optimal_num_clusters = silhouette_scores.index(max(silhouette_scores)) + 3
print("optimal clusters: ",optimal_num_clusters)
clustering = AgglomerativeClustering(n_clusters=optimal_num_clusters, metric='euclidean', linkage='ward')
# clustering = KMeans(n_clusters=optimal_num_clusters)
# clustering = AgglomerativeClustering(metric='euclidean', linkage='ward')
groups = clustering.fit_predict(table.values)
print(groups)

# clustering = AgglomerativeClustering(n_clusters=5, metric='euclidean', linkage='ward')
# groups = clustering.fit_predict(table.values)

# model=KMeans(n_clusters=3)
# model.fit(table.values)
# groups=model.predict(table.values)

print(groups)
grouped["groups"]=groups
print(grouped)

grouped = grouped.values

filtered_label0 = grouped[groups == 0]
filtered_label1 = grouped[groups == 1]
filtered_label2 = grouped[groups == 2]
filtered_label3 = grouped[groups == 3]
filtered_label4 = grouped[groups == 4]

#Plotting the results
print("data ",filtered_label0[:,0])
plt.scatter(filtered_label0[:,2], filtered_label0[:,0],color = 'red')
plt.scatter(filtered_label1[:,2], filtered_label1[:,0],color = 'black')
plt.scatter(filtered_label2[:,2], filtered_label2[:,0],color = 'orange')
plt.scatter(filtered_label3[:,2], filtered_label3[:,0],color = 'green')
plt.scatter(filtered_label4[:,2], filtered_label4[:,0],color = 'blue')
plt.show()



# linkage_matrix = linkage(table, method='ward')

# plt.figure(figsize=(10, 6))
# dendrogram(linkage_matrix)
# plt.title('Dendrogram')
# plt.xlabel('Inventory IDs')
# plt.ylabel('Distance')
# plt.show()