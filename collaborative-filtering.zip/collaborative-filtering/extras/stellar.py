import stellargraph as sg
from stellargraph import datasets
from IPython.display import display, HTML

dataset = sg.datasets.Cora()
display(HTML(dataset.description))
G, node_subjects = dataset.load()
print(G.info())
print(node_subjects)